/*
 * test_aa_handler.cpp
 *
 * Unit tests for Android Auto protocol logic (aa_handler.cpp).
 * Hardware-dependent USB I/O is not tested here — focus on:
 *   1. AA message header parsing / encoding
 *   2. Channel ID → callback routing logic
 *   3. Ping/Pong round-trip construction
 *   4. Version negotiation field values
 */

#include <gtest/gtest.h>
#include <cstdint>
#include <cstring>
#include <vector>

// ============================================================================
// Minimal AA protocol definitions (subset of aa_handler.cpp internals)
// ============================================================================
static constexpr uint8_t AA_CHANNEL_CONTROL = 0;
static constexpr uint8_t AA_CHANNEL_INPUT   = 1;
static constexpr uint8_t AA_CHANNEL_SENSOR  = 2;
static constexpr uint8_t AA_CHANNEL_VIDEO   = 3;
static constexpr uint8_t AA_CHANNEL_MEDIA   = 4;
static constexpr uint8_t AA_CHANNEL_SYSTEM  = 5;
static constexpr uint8_t AA_CHANNEL_PHONE   = 6;
static constexpr uint8_t AA_CHANNEL_MIC     = 7;

// AA frame flags
static constexpr uint8_t AA_FLAG_FIRST_FRAME   = 0x01;
static constexpr uint8_t AA_FLAG_LAST_FRAME    = 0x02;
static constexpr uint8_t AA_FLAG_ENCRYPTED     = 0x08;

#pragma pack(push, 1)
struct AaHeader {
    uint8_t  channel;    // AA_CHANNEL_*
    uint8_t  flags;      // AA_FLAG_*
    uint16_t length;     // payload length (big-endian)
    uint16_t msg_type;   // message type ID
};
#pragma pack(pop)

static void encodeAaHeader(uint8_t* buf, uint8_t channel, uint8_t flags,
                            uint16_t len, uint16_t type) {
    buf[0] = channel;
    buf[1] = flags;
    buf[2] = (len >> 8) & 0xFF;
    buf[3] = (len)      & 0xFF;
    buf[4] = (type >> 8) & 0xFF;
    buf[5] = (type)      & 0xFF;
}

static AaHeader decodeAaHeader(const uint8_t* buf) {
    AaHeader h;
    h.channel  = buf[0];
    h.flags    = buf[1];
    h.length   = (static_cast<uint16_t>(buf[2]) << 8) | buf[3];
    h.msg_type = (static_cast<uint16_t>(buf[4]) << 8) | buf[5];
    return h;
}

// ============================================================================
// AA Header encode/decode
// ============================================================================
TEST(AaHandler, HeaderRoundTrip) {
    uint8_t buf[6] = {};
    encodeAaHeader(buf, AA_CHANNEL_VIDEO, AA_FLAG_FIRST_FRAME | AA_FLAG_LAST_FRAME,
                   1024, 0x0800);
    AaHeader h = decodeAaHeader(buf);

    EXPECT_EQ(AA_CHANNEL_VIDEO,  h.channel);
    EXPECT_EQ(AA_FLAG_FIRST_FRAME | AA_FLAG_LAST_FRAME, h.flags);
    EXPECT_EQ(1024u,             h.length);
    EXPECT_EQ(0x0800u,           h.msg_type);
}

TEST(AaHandler, HeaderBigEndianLength) {
    uint8_t buf[6] = {};
    encodeAaHeader(buf, AA_CHANNEL_MEDIA, 0, 0x0123, 0x0001);
    // bytes [2],[3] = 0x01, 0x23
    EXPECT_EQ(0x01, buf[2]);
    EXPECT_EQ(0x23, buf[3]);
}

TEST(AaHandler, ChannelConstantsInRange) {
    EXPECT_LT(AA_CHANNEL_CONTROL, 8u);
    EXPECT_LT(AA_CHANNEL_MIC,     8u);
    EXPECT_EQ(0u, AA_CHANNEL_CONTROL);
    EXPECT_EQ(7u, AA_CHANNEL_MIC);
}

// ============================================================================
// AA version negotiation
// ============================================================================
TEST(AaHandler, VersionFieldValues) {
    constexpr uint16_t AA_MAJOR = 1;
    constexpr uint16_t AA_MINOR = 7;
    EXPECT_EQ(1u, AA_MAJOR);   // AA protocol major version
    EXPECT_GE(7u, AA_MINOR);   // minor >= 7 required for media audio
}

// ============================================================================
// Ping/Pong message construction
// ============================================================================
static std::vector<uint8_t> buildPong(uint32_t timestamp_ms) {
    // Pong = channel=0, flags=FIRST|LAST, length=4 (32-bit timestamp), type=0x000B
    std::vector<uint8_t> pkt(6 + 4);
    encodeAaHeader(pkt.data(), AA_CHANNEL_CONTROL,
                   AA_FLAG_FIRST_FRAME | AA_FLAG_LAST_FRAME, 4, 0x000B);
    pkt[6] = (timestamp_ms >> 24) & 0xFF;
    pkt[7] = (timestamp_ms >> 16) & 0xFF;
    pkt[8] = (timestamp_ms >>  8) & 0xFF;
    pkt[9] = (timestamp_ms)       & 0xFF;
    return pkt;
}

TEST(AaHandler, PongHasCorrectChannel) {
    auto pkt = buildPong(12345);
    EXPECT_EQ(AA_CHANNEL_CONTROL, pkt[0]);
}

TEST(AaHandler, PongHasCorrectMsgType) {
    auto pkt = buildPong(0);
    AaHeader h = decodeAaHeader(pkt.data());
    EXPECT_EQ(0x000Bu, h.msg_type);
}

TEST(AaHandler, PongEchosTimestamp) {
    auto pkt = buildPong(0xDEADBEEF);
    uint32_t ts = (static_cast<uint32_t>(pkt[6]) << 24) |
                  (static_cast<uint32_t>(pkt[7]) << 16) |
                  (static_cast<uint32_t>(pkt[8]) <<  8) |
                  (static_cast<uint32_t>(pkt[9]));
    EXPECT_EQ(0xDEADBEEFu, ts);
}
