# PiAutoSDK — Architecture & Integration Guide
## Version 1.0.0 | Android 16 / Raspberry Pi 4

---

## 1. Overview

PiAutoSDK is an OEM-grade C++17 library that enables a Raspberry Pi 4 running Android 16 (Automotive) to function as a certified Head Unit (HU) for both **Android Auto** (via AOAP + TLS) and **Apple CarPlay** (via iAP2 + MFi auth).

```
┌─────────────────────────────────────────────────────────┐
│                    Host Application                      │
│         (Java / Kotlin Android Automotive App)           │
└────────────────────┬────────────────────────────────────┘
                     │ JNI (libpiauto.so)
┌────────────────────▼────────────────────────────────────┐
│                   PiAutoSDK Core                         │
│   piauto_sdk.cpp  │  State Machine + Thread Dispatch    │
│   piauto_log.cpp  │  Logcat / stderr logging            │
└──────┬────────────┴──────────────┬─────────────────────┘
       │                           │
┌──────▼──────────┐   ┌────────────▼────────────────────┐
│   HAL Layer     │   │       Protocol Layer             │
│                 │   │                                  │
│ usb_detector   ◄───► aa_handler  (Android Auto)        │
│  libusb-1.0     │   │  AOAP + TLS 1.2 over USB bulk    │
│  AOAP switching │   │                                  │
│                 │   │ cp_handler  (CarPlay)             │
│ audio_engine    │   │  iAP2 + MFi RSA auth + sessions  │
│  tinyalsa/ALSA  │   │                                  │
│  SCHED_FIFO     │   └──────────────────────────────────┘
│  SPSC ring buf  │
└─────────────────┘
       │
┌──────▼──────────────────────────────────────────────────┐
│            Linux Kernel / ALSA                           │
│  Card 0: BT SCO (pcmC0D0)                               │
│  Card 1: PCM1808 mic (pcmC1D0)                          │
│  Card 2: TAS5828 speaker (pcmC2D0)                      │
│  Card 3: TEF6657A radio (pcmC3D0)                       │
└─────────────────────────────────────────────────────────┘
```

---

## 2. Directory Structure

```
PiAutoSDK/
├── core/
│   ├── include/
│   │   ├── piauto_types.h      All enums, structs, error codes
│   │   ├── piauto_callbacks.h  Callback function pointer definitions
│   │   ├── piauto_sdk.h        Public C API (only file app needs)
│   │   └── piauto_log.h        LOGE/LOGW/LOGI/LOGD/LOGV macros
│   └── src/
│       ├── piauto_sdk.cpp      Main lifecycle + state machine
│       └── piauto_log.cpp      Android logcat + Linux stderr backends
├── hal/
│   ├── include/
│   │   ├── usb_detector.h      libusb-1.0 hotplug API
│   │   └── audio_engine.h      tinyalsa audio engine API
│   └── src/
│       ├── usb_detector.cpp    AOAP USB switching + VID/PID detection
│       └── audio_engine.cpp    RT audio threads + SPSC ring buffers
├── protocol/
│   ├── android_auto/
│   │   ├── include/aa_handler.h
│   │   └── src/aa_handler.cpp  AOAP + TLS + AA message dispatch
│   └── carplay/
│       ├── include/cp_handler.h
│       └── src/cp_handler.cpp  iAP2 + MFi auth + CarPlay sessions
├── jni/
│   ├── src/piauto_jni.cpp      JNI bridge C++ ↔ Java
│   └── libpiauto.map.txt       Symbol visibility map
├── java/com/piauto/sdk/
│   └── PiAutoSDK.java          Java wrapper + AudioTrack + AudioRecord
├── tests/
│   ├── unit/                   Google Test unit tests per module
│   └── integration/
│       └── piauto_cli.cpp      Layer-by-layer CLI test harness
├── scripts/
│   ├── build.sh                Build (host / android / aosp / clean)
│   ├── gen_certs.sh            Generate dev TLS + MFi certificates
│   ├── install.sh              adb push + device verification
│   └── debug_log.sh            Focused logcat monitor per layer
├── configs/
│   ├── audio_policy_configuration.xml
│   ├── car_audio_configuration.xml
│   └── device.mk.snippet       AOSP integration properties
└── CMakeLists.txt              CMake build (host + NDK cross-compile)
```

---

## 3. Threading Model

| Thread | Name | Priority | Owner | Purpose |
|--------|------|----------|-------|---------|
| detect_thread | `PiAutoDetect` | NORMAL | `piauto_sdk.cpp` | USB hotplug poll loop (500ms interval) |
| proto_thread | `PiAutoProto` | NORMAL | `piauto_sdk.cpp` | Protocol message pump + state dispatch |
| aa_recv_thread | `PiAutoAARecv` | NORMAL | `aa_handler.cpp` | Android Auto USB bulk read loop |
| cp_recv_thread | `PiAutoCPRecv` | NORMAL | `cp_handler.cpp` | CarPlay USB bulk read loop |
| playback_thread | `PiAutoPlay` | SCHED_FIFO 90 | `audio_engine.cpp` | tinyalsa PCM write (real-time) |
| capture_thread | `PiAutoCap` | SCHED_FIFO 85 | `audio_engine.cpp` | tinyalsa PCM read (real-time) |

**Audio thread priorities require `CAP_SYS_NICE` or a SELinux policy allowing it.**  
In AOSP: add `allow piauto_app self:capability sys_nice;` to the SELinux policy.

---

## 4. State Machine

```
         ┌─────┐
    ─────►IDLE │◄─────────────────────────┐
         └──┬──┘                          │
            │ Start() + USB plugged        │ Stop() / error
         ┌──▼──────────┐                  │
         │ DETECTING   │                  │
         └──┬──────────┘                  │
            │ VID/PID matched             │
         ┌──▼──────────────┐              │
         │ AUTHENTICATING  │ (TLS/MFi)    │
         └──┬──────────────┘              │
            │ auth OK                     │
         ┌──▼──────────┐                  │
         │ NEGOTIATING │ (service disco)  │
         └──┬──────────┘                  │
            │ negotiation complete        │
         ┌──▼──────────┐                  │
         │  CONNECTED  │──── USB unplug ──┘
         └──┬──────────┘
            │ (screen off / call)
         ┌──▼──────────┐
         │  SUSPENDED  │
         └─────────────┘
```

---

## 5. Build Instructions

### 5.1 Host Build (for unit tests, CI)

```bash
# Install dependencies
sudo apt install cmake ninja-build libusb-1.0-0-dev libssl-dev

# Build + test
chmod +x scripts/build.sh
./scripts/build.sh host

# Expected output:
# [PASS] SDK version: 1.0.0
# [PASS] PiAutoSDK_Create
# [PASS] PiAutoSDK_Init
# [PASS] State is IDLE after init
# [PASS] PiAutoSDK_Destroy
# Tests run: 35/35 PASSED
```

### 5.2 Android NDK Cross-compile

```bash
export ANDROID_NDK=$HOME/Android/Sdk/ndk/27.0.12077973
./scripts/build.sh android

# Output: build/android/libpiauto.so (arm64-v8a)
```

### 5.3 AOSP In-tree Build

```bash
# Copy SDK to AOSP tree
cp -r PiAutoSDK/ $ANDROID_BUILD_TOP/vendor/piauto/sdk/

# Add to device.mk (see configs/device.mk.snippet)
# Then build
source build/envsetup.sh
lunch pi4_car-userdebug
m libpiauto -j$(nproc)

# Output: $OUT/vendor/lib64/libpiauto.so
```

---

## 6. Integration Steps

### Step 1: Generate dev certificates
```bash
./scripts/gen_certs.sh --push
```

### Step 2: Build and install
```bash
./scripts/build.sh android
./scripts/install.sh
```

### Step 3: Verify device properties
```bash
adb shell getprop ro.android.car.audio.enableaudiopatch
# Expected: true

adb shell ls /vendor/etc/piauto/
# Expected: audio_policy_configuration.xml car_audio_configuration.xml hu_cert.pem ...
```

### Step 4: Integrate in your Activity
```java
PiAutoSDK sdk = new PiAutoSDK.Builder(this)
    .setCallback(this)
    .setScreenWidth(1920)
    .setScreenHeight(720)
    .build();

sdk.start();
```

---

## 7. Layer-by-Layer Test Procedure

### Layer 0: Kernel / ALSA
```bash
adb shell cat /proc/asound/cards
# Expected: Card 2 [TAS5828] present

adb shell tinyplay /sdcard/test.wav -D 2 -d 0
# Expected: audio plays through TAS5828 speaker
```

### Layer 1: USB Detection
```bash
# Plug in Android phone
./scripts/debug_log.sh usb
# Expected: "[PiAutoSDK/usb_detector] Device attached VID:0x18D1"
# Expected: "[PiAutoSDK/usb_detector] AOAP switch OK, new PID=0x2D01"
```

### Layer 2: Protocol Handshake
```bash
./scripts/debug_log.sh aa
# Expected: "aa_version_handshake OK"
# Expected: "aa_ssl_handshake OK"
# Expected: "aa_service_discovery OK"
# Expected: State → CONNECTED
```

### Layer 3: Audio Streaming
```bash
./scripts/debug_log.sh audio
# Expected: "AudioEngine_WritePcm ch=0 frames=256"
# Expected: No "underrun" messages
```

### Layer 4: Full SDK via CLI
```bash
# On device (if piauto_cli was pushed)
adb push build/android/piauto_cli /data/local/tmp/
adb shell /data/local/tmp/piauto_cli all
```

---

## 8. Log Tags Reference

| Tag | Source File | What It Tells You |
|-----|------------|-------------------|
| `PiAutoSDK` | piauto_sdk.cpp | Lifecycle, state transitions |
| `PiAutoSDK/usb_detector` | usb_detector.cpp | USB attach/detach, AOAP |
| `PiAutoSDK/audio_engine` | audio_engine.cpp | PCM writes, underruns |
| `PiAutoSDK/aa_handler` | aa_handler.cpp | AA protocol messages |
| `PiAutoSDK/cp_handler` | cp_handler.cpp | CarPlay iAP2 messages |
| `PiAutoJNI` | piauto_jni.cpp | JNI calls, Java callbacks |

### Quick logcat commands
```bash
# All SDK logs
adb logcat -s PiAutoSDK:V PiAutoJNI:V

# Audio only (SDK + system)
adb logcat -s PiAutoSDK/audio_engine:V AudioFlinger:I AudioTrack:W

# Android Auto protocol trace
adb logcat -s PiAutoSDK/aa_handler:V

# CarPlay protocol trace  
adb logcat -s PiAutoSDK/cp_handler:V

# Crash / tombstone
adb logcat -s DEBUG:* | grep -E "SIGSEGV|libpiauto"
```

---

## 9. Known Limitations & TODOs

| # | Item | Priority |
|---|------|----------|
| 1 | Real MFi hardware chip support (vs software fallback) | HIGH |
| 2 | Wi-Fi projection (AA wireless / CarPlay wireless over BTLE+WiFi) | HIGH |
| 3 | Protobuf parsing for AA message payloads (currently stub) | MED |
| 4 | Android Auto phone call audio routing through BT SCO | MED |
| 5 | CarPlay HID (steering wheel buttons) | MED |
| 6 | Multi-touch event forwarding (currently single-touch) | LOW |
| 7 | Day/night mode sync with vehicle CAN bus | LOW |
| 8 | SELinux policy files (`sepolicy/`) | MED |

---

## 10. License

```
Copyright (C) 2026 PiAuto Inc. All rights reserved.
Proprietary and confidential.
```

**Third-party dependencies:**
- libusb-1.0: LGPL-2.1
- OpenSSL / BoringSSL: OpenSSL License
- tinyalsa: BSD 3-Clause
- Google Test: BSD 3-Clause
