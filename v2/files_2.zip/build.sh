#!/usr/bin/env bash
# =============================================================================
# build.sh — PiAutoSDK build script
#
# Supports three build modes:
#   host        Build for the development host (x86_64 Linux) with GTest
#   android     Cross-compile for arm64-v8a using Android NDK
#   aosp        Build inside an AOSP tree (calls mm/mma)
#
# Usage:
#   ./scripts/build.sh host               # quick host build + tests
#   ./scripts/build.sh android            # NDK cross-compile
#   ./scripts/build.sh android --asan     # with AddressSanitizer
#   ./scripts/build.sh aosp               # inside Android tree
#   ./scripts/build.sh clean              # remove all build artifacts
#
# Prerequisites (host):
#   apt install cmake ninja-build libusb-1.0-0-dev libssl-dev libtinyalsa-dev
#
# Prerequisites (android):
#   Set ANDROID_NDK to your NDK path, e.g.:
#   export ANDROID_NDK=$HOME/Android/Sdk/ndk/27.0.12077973
# =============================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SDK_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
BUILD_DIR="$SDK_ROOT/build"

MODE="${1:-host}"
ASAN=OFF

# Parse flags
shift || true
while [[ $# -gt 0 ]]; do
    case "$1" in
        --asan)   ASAN=ON ;;
        --clean)  MODE=clean ;;
        *)        echo "Unknown flag: $1"; exit 1 ;;
    esac
    shift
done

# ─────────────────────────────────────────────────────────────────────────────
# clean
# ─────────────────────────────────────────────────────────────────────────────
if [[ "$MODE" == "clean" ]]; then
    echo "[build.sh] Cleaning $BUILD_DIR ..."
    rm -rf "$BUILD_DIR"
    echo "[build.sh] Clean done."
    exit 0
fi

# ─────────────────────────────────────────────────────────────────────────────
# host — build for current machine (x86_64 or aarch64)
# ─────────────────────────────────────────────────────────────────────────────
if [[ "$MODE" == "host" ]]; then
    echo "=== PiAutoSDK: host build ==="
    mkdir -p "$BUILD_DIR/host"
    cd "$BUILD_DIR/host"

    cmake "$SDK_ROOT" \
        -GNinja \
        -DCMAKE_BUILD_TYPE=Debug \
        -DPIAUTO_BUILD_TESTS=ON \
        -DPIAUTO_ANDROID_BUILD=OFF \
        -DPIAUTO_ENABLE_ASAN="$ASAN" \
        -DCMAKE_EXPORT_COMPILE_COMMANDS=ON

    ninja -j"$(nproc)"

    echo ""
    echo "=== Build artifacts ==="
    echo "  Shared lib : $BUILD_DIR/host/libpiauto.so"
    echo "  CLI harness: $BUILD_DIR/host/piauto_cli"
    echo "  Unit tests : $BUILD_DIR/host/piauto_tests"

    echo ""
    echo "=== Running unit tests ==="
    ctest --test-dir "$BUILD_DIR/host" --output-on-failure -j"$(nproc)"

    echo ""
    echo "=== Running integration CLI ==="
    "$BUILD_DIR/host/piauto_cli" all || true   # may skip USB tests without hardware

    echo ""
    echo "[build.sh] Host build DONE."
    exit 0
fi

# ─────────────────────────────────────────────────────────────────────────────
# android — cross-compile with Android NDK (arm64-v8a)
# ─────────────────────────────────────────────────────────────────────────────
if [[ "$MODE" == "android" ]]; then
    if [[ -z "${ANDROID_NDK:-}" ]]; then
        echo "[ERROR] ANDROID_NDK not set. Example:"
        echo "  export ANDROID_NDK=\$HOME/Android/Sdk/ndk/27.0.12077973"
        exit 1
    fi

    TOOLCHAIN="$ANDROID_NDK/build/cmake/android.toolchain.cmake"
    if [[ ! -f "$TOOLCHAIN" ]]; then
        echo "[ERROR] NDK toolchain not found at: $TOOLCHAIN"
        exit 1
    fi

    echo "=== PiAutoSDK: Android NDK build ==="
    echo "  NDK: $ANDROID_NDK"
    mkdir -p "$BUILD_DIR/android"
    cd "$BUILD_DIR/android"

    cmake "$SDK_ROOT" \
        -GNinja \
        -DCMAKE_TOOLCHAIN_FILE="$TOOLCHAIN" \
        -DANDROID_ABI=arm64-v8a \
        -DANDROID_PLATFORM=android-35 \
        -DCMAKE_BUILD_TYPE=RelWithDebInfo \
        -DPIAUTO_BUILD_TESTS=OFF \
        -DPIAUTO_ANDROID_BUILD=ON \
        -DPIAUTO_ENABLE_ASAN="$ASAN"

    ninja -j"$(nproc)"

    echo ""
    echo "=== Build artifacts ==="
    echo "  Shared lib : $BUILD_DIR/android/libpiauto.so"
    echo ""
    echo "  To push to device:"
    echo "    adb push $BUILD_DIR/android/libpiauto.so /vendor/lib64/"
    echo "    adb shell chmod 644 /vendor/lib64/libpiauto.so"
    echo ""
    echo "[build.sh] Android build DONE."
    exit 0
fi

# ─────────────────────────────────────────────────────────────────────────────
# aosp — build inside AOSP tree using mm
# ─────────────────────────────────────────────────────────────────────────────
if [[ "$MODE" == "aosp" ]]; then
    if [[ -z "${ANDROID_BUILD_TOP:-}" ]]; then
        echo "[ERROR] ANDROID_BUILD_TOP not set. Run 'source build/envsetup.sh && lunch' first."
        exit 1
    fi

    echo "=== PiAutoSDK: AOSP mm build ==="
    # Copy SDK source to AOSP tree if not already there
    AOSP_SDK_PATH="$ANDROID_BUILD_TOP/vendor/piauto/sdk"
    if [[ ! -d "$AOSP_SDK_PATH" ]]; then
        echo "Copying SDK to $AOSP_SDK_PATH ..."
        mkdir -p "$AOSP_SDK_PATH"
        cp -r "$SDK_ROOT"/* "$AOSP_SDK_PATH/"
    fi

    cd "$AOSP_SDK_PATH"
    # mm builds just this module
    "$ANDROID_BUILD_TOP/build/soong/soong_ui.bash" --make-mode libpiauto

    echo ""
    echo "[build.sh] AOSP build DONE."
    echo "  Output: \$OUT/vendor/lib64/libpiauto.so"
    exit 0
fi

echo "[ERROR] Unknown mode: $MODE (use: host | android | aosp | clean)"
exit 1
