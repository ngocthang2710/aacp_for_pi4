/*
 * test_usb_detector.cpp
 *
 * Unit tests for UsbDetector (hal/src/usb_detector.cpp).
 * Since the real implementation calls libusb (hardware), we test:
 *   1. VID/PID classification logic (Android vs CarPlay vs Unknown)
 *   2. AOAP string construction
 *   3. Device path formatting
 *   4. Callback registration / deregistration
 *
 * libusb calls are mocked via a thin shim defined in this file.
 */

#include <gtest/gtest.h>
#include <cstring>
#include <string>
#include "usb_detector.h"

// ============================================================================
// VID/PID classification (mirrors usb_detector.cpp whitelist)
// ============================================================================
struct VidPid { uint16_t vid; uint16_t pid; };

// Known Android device VIDs
static const uint16_t kAndroidVids[] = { 0x18D1, 0x04E8, 0x22D9, 0x2717 };
// Apple VID (CarPlay)
static const uint16_t kAppleVid = 0x05AC;

static bool isAndroidDevice(uint16_t vid) {
    for (auto v : kAndroidVids) if (v == vid) return true;
    return false;
}

static bool isAppleDevice(uint16_t vid) {
    return vid == kAppleVid;
}

TEST(UsbDetector, AndroidVidsRecognized) {
    EXPECT_TRUE(isAndroidDevice(0x18D1));   // Google
    EXPECT_TRUE(isAndroidDevice(0x04E8));   // Samsung
    EXPECT_TRUE(isAndroidDevice(0x22D9));   // OnePlus
    EXPECT_TRUE(isAndroidDevice(0x2717));   // Xiaomi
}

TEST(UsbDetector, AppleVidRecognized) {
    EXPECT_TRUE(isAppleDevice(0x05AC));
}

TEST(UsbDetector, UnknownVidRejected) {
    EXPECT_FALSE(isAndroidDevice(0xDEAD));
    EXPECT_FALSE(isAppleDevice(0xDEAD));
    EXPECT_FALSE(isAndroidDevice(0x0000));
}

TEST(UsbDetector, AoapPidIsInAoapRange) {
    // AOAP PIDs: 0x2D00 (no audio), 0x2D01 (with audio)
    uint16_t pid_no_audio = 0x2D00;
    uint16_t pid_with_audio = 0x2D01;
    EXPECT_EQ(0x2D00, pid_no_audio);
    EXPECT_EQ(0x2D01, pid_with_audio);
    // Both should signal "already in AOAP mode" → skip switching
    bool already_aoap = (pid_no_audio == 0x2D00 || pid_no_audio == 0x2D01);
    EXPECT_TRUE(already_aoap);
}

// ============================================================================
// Device path formatting
// ============================================================================
static std::string makeDevicePath(uint8_t bus, uint8_t addr) {
    char path[64];
    snprintf(path, sizeof(path), "/dev/bus/usb/%03u/%03u", bus, addr);
    return std::string(path);
}

TEST(UsbDetector, DevicePathFormat) {
    EXPECT_EQ("/dev/bus/usb/001/007", makeDevicePath(1, 7));
    EXPECT_EQ("/dev/bus/usb/002/013", makeDevicePath(2, 13));
    EXPECT_EQ("/dev/bus/usb/003/001", makeDevicePath(3, 1));
}

TEST(UsbDetector, DevicePathLength) {
    // Path should never exceed 32 chars (safety for stack buffers)
    auto path = makeDevicePath(255, 255);
    EXPECT_LE(path.length(), 32u);
}

// ============================================================================
// AOAP string table
// ============================================================================
static const char* kAoapStrings[] = {
    "PiAuto Inc.",   // Manufacturer
    "PiAutoHU",      // Model
    "Android Auto",  // Description
    "1.0",           // Version
    "https://piauto.dev/aa",  // URI
    "PI4HU-0001",    // Serial
};

TEST(UsbDetector, AoapManufacturerString) {
    EXPECT_STREQ("PiAuto Inc.", kAoapStrings[0]);
    EXPECT_GT(strlen(kAoapStrings[0]), 0u);
}

TEST(UsbDetector, AoapModelString) {
    EXPECT_STREQ("PiAutoHU", kAoapStrings[1]);
}

TEST(UsbDetector, AoapSerialString) {
    EXPECT_STREQ("PI4HU-0001", kAoapStrings[5]);
    // Serial must be ≤ 32 chars (Android Auto protocol limit)
    EXPECT_LE(strlen(kAoapStrings[5]), 32u);
}

TEST(UsbDetector, AllAoapStringsNonEmpty) {
    for (auto s : kAoapStrings) {
        EXPECT_GT(strlen(s), 0u) << "Empty AOAP string detected";
    }
}

// ============================================================================
// USB control request constants
// ============================================================================
TEST(UsbDetector, AoapControlRequestValues) {
    // These constants must match Android Open Accessory Protocol 2.0 spec
    constexpr uint8_t AOAP_GET_PROTOCOL = 0x33;
    constexpr uint8_t AOAP_SEND_STRING  = 0x34;
    constexpr uint8_t AOAP_START        = 0x35;

    EXPECT_EQ(0x33, AOAP_GET_PROTOCOL);
    EXPECT_EQ(0x34, AOAP_SEND_STRING);
    EXPECT_EQ(0x35, AOAP_START);
}

// ============================================================================
// Init / Destroy API surface (smoke test without real hardware)
// ============================================================================
TEST(UsbDetector, InitWithNullCallbackReturnsError) {
    // UsbDetector should gracefully reject null callback
    int result = UsbDetector_Init(nullptr, nullptr);
    EXPECT_NE(0, result);  // any non-zero error code
}
