/*
 * piauto_cli.cpp — Layer-by-layer integration test harness
 *
 * This is a standalone command-line tool (non-Android) for testing each
 * layer of PiAutoSDK independently without needing a full Android system.
 *
 * Usage:
 *   ./piauto_cli <layer> [options]
 *
 * Layers:
 *   usb      — List USB devices and attempt AOAP detection
 *   audio    — Open ALSA card, play test tone, record mic
 *   aa       — Simulate Android Auto handshake (requires real phone)
 *   cp       — Simulate CarPlay handshake (requires real iPhone)
 *   sdk      — Full SDK init → start → 10s → stop cycle
 *
 * Output format:
 *   [PASS] test description
 *   [FAIL] test description — reason
 *   [INFO] informational message
 *
 * Exit code: 0 = all PASS, 1 = any FAIL
 */

#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <unistd.h>
#include <atomic>
#include <thread>
#include <chrono>

#include "piauto_sdk.h"
#include "piauto_log.h"

// ============================================================================
// Tiny test framework
// ============================================================================
static int g_pass = 0;
static int g_fail = 0;

#define TEST_PASS(msg, ...)  do { printf("[PASS] " msg "\n", ##__VA_ARGS__); g_pass++; } while(0)
#define TEST_FAIL(msg, ...)  do { printf("[FAIL] " msg "\n", ##__VA_ARGS__); g_fail++; } while(0)
#define TEST_INFO(msg, ...)  do { printf("[INFO] " msg "\n", ##__VA_ARGS__); } while(0)
#define TEST_SKIP(msg, ...)  do { printf("[SKIP] " msg "\n", ##__VA_ARGS__); } while(0)

// ============================================================================
// Layer 0: SDK version check
// ============================================================================
static void test_version() {
    TEST_INFO("=== Layer 0: Version Check ===");
    const char* ver = PiAutoSDK_GetVersion();
    if (ver && strlen(ver) > 0) {
        TEST_PASS("SDK version: %s", ver);
    } else {
        TEST_FAIL("PiAutoSDK_GetVersion() returned null/empty");
    }
}

// ============================================================================
// Layer 1: SDK init / destroy lifecycle
// ============================================================================
static void test_sdk_lifecycle() {
    TEST_INFO("=== Layer 1: SDK Lifecycle ===");

    PiAutoConfig cfg{};
    cfg.screen_width  = 1920;
    cfg.screen_height = 720;
    cfg.screen_dpi    = 160;
    cfg.target_fps    = 60;
    cfg.night_mode    = false;

    PiAutoCallbacks cbs{};
    // Null callbacks are valid (SDK should not crash)

    PiAutoSDKHandle h = nullptr;
    PiAutoResult r = PiAutoSDK_Create(&h);
    if (r != PIAUTO_OK || h == nullptr) {
        TEST_FAIL("PiAutoSDK_Create failed: %s", PiAutoSDK_ResultToString(r));
        return;
    }
    TEST_PASS("PiAutoSDK_Create");

    r = PiAutoSDK_Init(h, &cfg, &cbs);
    if (r != PIAUTO_OK) {
        TEST_FAIL("PiAutoSDK_Init failed: %s", PiAutoSDK_ResultToString(r));
        PiAutoSDK_Destroy(h);
        return;
    }
    TEST_PASS("PiAutoSDK_Init");

    // State should be IDLE before start
    int state = PiAutoSDK_GetState(h);
    if (state == PIAUTO_STATE_IDLE) {
        TEST_PASS("State is IDLE after init");
    } else {
        TEST_FAIL("Expected IDLE (0) but got %d", state);
    }

    PiAutoSDK_Destroy(h);
    TEST_PASS("PiAutoSDK_Destroy");
}

// ============================================================================
// Layer 2: Start / Stop with USB detection
// ============================================================================
static std::atomic<bool> g_state_changed{false};
static std::atomic<int>  g_last_state{-1};

static void on_state_cb(PiAutoConnectionState state, PiAutoProtocol proto, void* /*user*/) {
    TEST_INFO("State callback: state=%d protocol=%d", (int)state, (int)proto);
    g_last_state.store((int)state);
    g_state_changed.store(true);
}

static void test_start_stop() {
    TEST_INFO("=== Layer 2: Start / Stop ===");

    PiAutoConfig cfg{};
    cfg.screen_width  = 1920;
    cfg.screen_height = 720;
    cfg.screen_dpi    = 160;
    cfg.target_fps    = 60;

    PiAutoCallbacks cbs{};
    cbs.on_connection_state_changed = on_state_cb;

    PiAutoSDKHandle h = nullptr;
    PiAutoSDK_Create(&h);
    PiAutoSDK_Init(h, &cfg, &cbs);

    PiAutoResult r = PiAutoSDK_Start(h);
    if (r != PIAUTO_OK) {
        TEST_FAIL("PiAutoSDK_Start: %s", PiAutoSDK_ResultToString(r));
        PiAutoSDK_Destroy(h);
        return;
    }
    TEST_PASS("PiAutoSDK_Start");

    // Wait up to 2s for state to transition to DETECTING
    auto deadline = std::chrono::steady_clock::now() + std::chrono::seconds(2);
    while (!g_state_changed.load() && std::chrono::steady_clock::now() < deadline) {
        std::this_thread::sleep_for(std::chrono::milliseconds(50));
    }

    if (g_last_state.load() == PIAUTO_STATE_DETECTING) {
        TEST_PASS("State transitioned to DETECTING");
    } else if (g_last_state.load() == -1) {
        TEST_SKIP("No USB device connected — state did not change (expected in CI)");
    } else {
        TEST_INFO("State is %d (may be OK if device already connected)", g_last_state.load());
    }

    r = PiAutoSDK_Stop(h);
    if (r == PIAUTO_OK) {
        TEST_PASS("PiAutoSDK_Stop");
    } else {
        TEST_FAIL("PiAutoSDK_Stop: %s", PiAutoSDK_ResultToString(r));
    }

    PiAutoSDK_Destroy(h);
}

// ============================================================================
// Layer 3: Stats check
// ============================================================================
static void test_stats() {
    TEST_INFO("=== Layer 3: Stats ===");

    PiAutoConfig cfg{};
    cfg.screen_width = 800; cfg.screen_height = 480;
    PiAutoCallbacks cbs{};
    PiAutoSDKHandle h = nullptr;
    PiAutoSDK_Create(&h);
    PiAutoSDK_Init(h, &cfg, &cbs);
    PiAutoSDK_Start(h);

    std::this_thread::sleep_for(std::chrono::milliseconds(500));

    PiAutoStats stats{};
    PiAutoResult r = PiAutoSDK_GetStats(h, &stats);
    if (r == PIAUTO_OK) {
        TEST_PASS("GetStats OK — frames_rx=%u audio_underruns=%u",
                  stats.video_frames_received, stats.audio_underruns);
    } else {
        TEST_FAIL("GetStats failed: %s", PiAutoSDK_ResultToString(r));
    }

    PiAutoSDK_Stop(h);
    PiAutoSDK_Destroy(h);
}

// ============================================================================
// Layer 4: Log level change
// ============================================================================
static void test_log_level() {
    TEST_INFO("=== Layer 4: Log Level ===");

    PiAutoSDKHandle h = nullptr;
    PiAutoConfig cfg{}; PiAutoCallbacks cbs{};
    PiAutoSDK_Create(&h);
    PiAutoSDK_Init(h, &cfg, &cbs);

    PiAutoSDK_SetLogLevel(h, PIAUTO_LOG_VERBOSE);
    TEST_PASS("SetLogLevel VERBOSE");

    PiAutoSDK_SetLogLevel(h, PIAUTO_LOG_ERROR);
    TEST_PASS("SetLogLevel ERROR");

    PiAutoSDK_Destroy(h);
}

// ============================================================================
// main
// ============================================================================
int main(int argc, char* argv[]) {
    const char* layer = (argc > 1) ? argv[1] : "all";

    printf("\n============================\n");
    printf("  PiAutoSDK Integration CLI \n");
    printf("============================\n\n");

    if (strcmp(layer, "version") == 0 || strcmp(layer, "all") == 0) test_version();
    if (strcmp(layer, "lifecycle") == 0 || strcmp(layer, "all") == 0) test_sdk_lifecycle();
    if (strcmp(layer, "start") == 0 || strcmp(layer, "all") == 0) test_start_stop();
    if (strcmp(layer, "stats") == 0 || strcmp(layer, "all") == 0) test_stats();
    if (strcmp(layer, "log") == 0 || strcmp(layer, "all") == 0) test_log_level();

    printf("\n============================\n");
    printf("  PASS: %d   FAIL: %d\n", g_pass, g_fail);
    printf("============================\n\n");

    return g_fail > 0 ? 1 : 0;
}
