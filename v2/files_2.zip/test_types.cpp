/*
 * test_types.cpp — Unit tests for piauto_types.h enums and structs
 *
 * These tests verify:
 *  - Enum values match documented constants (guard against accidental renumbering)
 *  - PiAutoConfig default-initialization is sane
 *  - PiAutoAudioFormat size/layout
 *
 * Build: cmake -B build && cmake --build build && ./build/piauto_tests
 */

#include <gtest/gtest.h>
#include "piauto_types.h"

// ============================================================================
// PiAutoResult
// ============================================================================
TEST(PiAutoResult, SuccessIsZero) {
    EXPECT_EQ(0, static_cast<int>(PIAUTO_OK));
}

TEST(PiAutoResult, ErrorCodesAreNegative) {
    EXPECT_LT(static_cast<int>(PIAUTO_ERR_INVALID_PARAM),  0);
    EXPECT_LT(static_cast<int>(PIAUTO_ERR_NOT_INITIALIZED), 0);
    EXPECT_LT(static_cast<int>(PIAUTO_ERR_ALREADY_STARTED), 0);
    EXPECT_LT(static_cast<int>(PIAUTO_ERR_USB_FAILED),      0);
    EXPECT_LT(static_cast<int>(PIAUTO_ERR_AUTH_FAILED),     0);
    EXPECT_LT(static_cast<int>(PIAUTO_ERR_TIMEOUT),         0);
    EXPECT_LT(static_cast<int>(PIAUTO_ERR_NO_MEMORY),       0);
}

// ============================================================================
// PiAutoConnectionState ordering
// ============================================================================
TEST(ConnectionState, OrderingMatchesLifecycle) {
    // IDLE → DETECTING → AUTHENTICATING → NEGOTIATING → CONNECTED
    EXPECT_LT(static_cast<int>(PIAUTO_STATE_IDLE),
              static_cast<int>(PIAUTO_STATE_DETECTING));
    EXPECT_LT(static_cast<int>(PIAUTO_STATE_DETECTING),
              static_cast<int>(PIAUTO_STATE_AUTHENTICATING));
    EXPECT_LT(static_cast<int>(PIAUTO_STATE_AUTHENTICATING),
              static_cast<int>(PIAUTO_STATE_NEGOTIATING));
    EXPECT_LT(static_cast<int>(PIAUTO_STATE_NEGOTIATING),
              static_cast<int>(PIAUTO_STATE_CONNECTED));
}

// ============================================================================
// PiAutoAudioFormat
// ============================================================================
TEST(PiAutoAudioFormat, DefaultValuesAreValid) {
    PiAutoAudioFormat fmt{};
    // Zero-initialized struct — sample_rate of 0 is invalid in practice,
    // but the struct itself should be trivially constructible.
    EXPECT_EQ(0u, fmt.sample_rate);
    EXPECT_EQ(0u, fmt.channel_count);
}

TEST(PiAutoAudioFormat, TypicalValuesAreSane) {
    PiAutoAudioFormat fmt{ .sample_rate = 48000, .channel_count = 2, .bit_depth = 16 };
    EXPECT_EQ(48000u, fmt.sample_rate);
    EXPECT_EQ(2u,     fmt.channel_count);
    EXPECT_EQ(16u,    fmt.bit_depth);
}

// ============================================================================
// PiAutoConfig
// ============================================================================
TEST(PiAutoConfig, CanBeZeroInitialized) {
    PiAutoConfig cfg{};
    EXPECT_EQ(0u,    cfg.screen_width);
    EXPECT_EQ(0u,    cfg.screen_height);
    EXPECT_FALSE(cfg.night_mode);
}

TEST(PiAutoConfig, TypicalIVIConfig) {
    PiAutoConfig cfg{
        .screen_width  = 1920,
        .screen_height = 720,
        .screen_dpi    = 160,
        .target_fps    = 60,
        .night_mode    = false,
    };
    EXPECT_EQ(1920u, cfg.screen_width);
    EXPECT_EQ(720u,  cfg.screen_height);
    EXPECT_EQ(160u,  cfg.screen_dpi);
    EXPECT_EQ(60u,   cfg.target_fps);
}
