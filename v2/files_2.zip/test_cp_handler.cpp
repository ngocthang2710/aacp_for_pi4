/*
 * test_cp_handler.cpp
 *
 * Unit tests for CarPlay iAP2 packet logic (cp_handler.cpp).
 * Tests cover:
 *   1. iAP2 packet construction (SOP, length, control, session, payload, checksum)
 *   2. XOR checksum correctness
 *   3. iAP2 link handshake byte sequences (SYN / SYNACK / ACK)
 *   4. MFi auth message type IDs
 *   5. CarPlay session message construction
 */

#include <gtest/gtest.h>
#include <cstdint>
#include <vector>
#include <numeric>

// ============================================================================
// iAP2 packet definitions (mirrors cp_handler.cpp)
// ============================================================================
static constexpr uint8_t IAP2_SOP1 = 0xFF;
static constexpr uint8_t IAP2_SOP2 = 0x5A;

// iAP2 link packet types
static constexpr uint8_t IAP2_PKT_SYN    = 0x01;
static constexpr uint8_t IAP2_PKT_SYNACK = 0x02;
static constexpr uint8_t IAP2_PKT_ACK    = 0x03;
static constexpr uint8_t IAP2_PKT_DATA   = 0x04;
static constexpr uint8_t IAP2_PKT_EACK   = 0x06;

// Session IDs
static constexpr uint8_t IAP2_SESSION_CONTROL = 0x00;
static constexpr uint8_t IAP2_SESSION_CARPLAY  = 0x01;
static constexpr uint8_t IAP2_SESSION_HID      = 0x02;
static constexpr uint8_t IAP2_SESSION_AIRPLAY  = 0x03;

// MFi auth message type IDs
static constexpr uint16_t MFI_MSG_REQ_CERT  = 0xAA00;
static constexpr uint16_t MFI_MSG_CERT_RESP = 0xAA01;
static constexpr uint16_t MFI_MSG_REQ_SIGN  = 0xAA02;
static constexpr uint16_t MFI_MSG_SIGN_RESP = 0xAA03;
static constexpr uint16_t MFI_MSG_AUTH_OK   = 0xAA05;

// Build a minimal iAP2 packet: SOP(2) + len(2,BE) + ctrl(1) + session(1) + payload + checksum(1)
static std::vector<uint8_t> buildIap2Packet(uint8_t ctrl, uint8_t session,
                                             const std::vector<uint8_t>& payload) {
    uint16_t total_len = static_cast<uint16_t>(7 + payload.size()); // header(6) + cksum(1)
    std::vector<uint8_t> pkt;
    pkt.push_back(IAP2_SOP1);
    pkt.push_back(IAP2_SOP2);
    pkt.push_back((total_len >> 8) & 0xFF);
    pkt.push_back((total_len)      & 0xFF);
    pkt.push_back(ctrl);
    pkt.push_back(session);
    for (auto b : payload) pkt.push_back(b);

    // Checksum = XOR of all bytes after SOP
    uint8_t cksum = 0;
    for (size_t i = 2; i < pkt.size(); i++) cksum ^= pkt[i];
    pkt.push_back(cksum);
    return pkt;
}

static bool verifyChecksum(const std::vector<uint8_t>& pkt) {
    if (pkt.size() < 7) return false;
    uint8_t expected = 0;
    for (size_t i = 2; i < pkt.size() - 1; i++) expected ^= pkt[i];
    return expected == pkt.back();
}

// ============================================================================
// SOP and packet structure
// ============================================================================
TEST(CpHandler, PacketStartsWithSOP) {
    auto pkt = buildIap2Packet(IAP2_PKT_DATA, IAP2_SESSION_CARPLAY, {0x01, 0x02});
    EXPECT_EQ(IAP2_SOP1, pkt[0]);
    EXPECT_EQ(IAP2_SOP2, pkt[1]);
}

TEST(CpHandler, PacketLengthFieldIsCorrect) {
    std::vector<uint8_t> payload = {0xAA, 0xBB, 0xCC};
    auto pkt = buildIap2Packet(IAP2_PKT_DATA, IAP2_SESSION_CONTROL, payload);
    uint16_t len = (static_cast<uint16_t>(pkt[2]) << 8) | pkt[3];
    // header(6) + payload(3) + cksum(1) = 10
    EXPECT_EQ(10u, len);
    EXPECT_EQ(pkt.size(), static_cast<size_t>(len));
}

TEST(CpHandler, ChecksumIsValid) {
    auto pkt = buildIap2Packet(IAP2_PKT_SYN, IAP2_SESSION_CONTROL, {});
    EXPECT_TRUE(verifyChecksum(pkt));
}

TEST(CpHandler, ChecksumDetectsCorruption) {
    auto pkt = buildIap2Packet(IAP2_PKT_DATA, IAP2_SESSION_CARPLAY, {0x11, 0x22});
    pkt[4] ^= 0xFF;   // corrupt control byte
    EXPECT_FALSE(verifyChecksum(pkt));
}

TEST(CpHandler, EmptyPayloadPacketIsValid) {
    auto pkt = buildIap2Packet(IAP2_PKT_ACK, IAP2_SESSION_CONTROL, {});
    EXPECT_TRUE(verifyChecksum(pkt));
    EXPECT_EQ(7u, pkt.size());  // SOP(2)+len(2)+ctrl(1)+session(1)+cksum(1)
}

// ============================================================================
// Link handshake sequence
// ============================================================================
TEST(CpHandler, LinkHandshakeOrder) {
    // HU sends SYN → iPhone sends SYNACK → HU sends ACK
    EXPECT_LT(IAP2_PKT_SYN,    IAP2_PKT_SYNACK);
    EXPECT_LT(IAP2_PKT_SYNACK, IAP2_PKT_ACK);
}

TEST(CpHandler, SynPacketHasControlSession) {
    auto syn = buildIap2Packet(IAP2_PKT_SYN, IAP2_SESSION_CONTROL, {});
    EXPECT_EQ(IAP2_SESSION_CONTROL, syn[5]);
}

// ============================================================================
// Session IDs
// ============================================================================
TEST(CpHandler, SessionIdsAreUnique) {
    uint8_t sessions[] = {
        IAP2_SESSION_CONTROL,
        IAP2_SESSION_CARPLAY,
        IAP2_SESSION_HID,
        IAP2_SESSION_AIRPLAY
    };
    for (size_t i = 0; i < 4; i++)
        for (size_t j = i + 1; j < 4; j++)
            EXPECT_NE(sessions[i], sessions[j]);
}

// ============================================================================
// MFi Auth message types
// ============================================================================
TEST(CpHandler, MfiAuthMsgTypesAreInAaRange) {
    // All MFi auth messages start with 0xAA (Apple auth namespace)
    EXPECT_EQ(0xAA00u, MFI_MSG_REQ_CERT);
    EXPECT_EQ(0xAA05u, MFI_MSG_AUTH_OK);
}

TEST(CpHandler, MfiRequestResponsePairings) {
    // Each request should have a corresponding response type
    EXPECT_EQ(MFI_MSG_REQ_CERT  + 1, MFI_MSG_CERT_RESP);
    EXPECT_EQ(MFI_MSG_REQ_SIGN  + 1, MFI_MSG_SIGN_RESP);
}

// ============================================================================
// CarPlay screen config message
// ============================================================================
static std::vector<uint8_t> buildScreenConfig(uint16_t w, uint16_t h,
                                               uint8_t fps, bool night_mode) {
    return {
        static_cast<uint8_t>((w >> 8) & 0xFF),
        static_cast<uint8_t>(w        & 0xFF),
        static_cast<uint8_t>((h >> 8) & 0xFF),
        static_cast<uint8_t>(h        & 0xFF),
        fps,
        static_cast<uint8_t>(night_mode ? 1 : 0)
    };
}

TEST(CpHandler, ScreenConfigEncoding) {
    auto cfg = buildScreenConfig(1920, 720, 60, false);
    uint16_t w = (static_cast<uint16_t>(cfg[0]) << 8) | cfg[1];
    uint16_t h = (static_cast<uint16_t>(cfg[2]) << 8) | cfg[3];
    EXPECT_EQ(1920u, w);
    EXPECT_EQ(720u,  h);
    EXPECT_EQ(60u,   cfg[4]);
    EXPECT_EQ(0u,    cfg[5]);   // night_mode=false
}

TEST(CpHandler, NightModeFlag) {
    auto cfg = buildScreenConfig(800, 480, 30, true);
    EXPECT_EQ(1u, cfg[5]);
}
