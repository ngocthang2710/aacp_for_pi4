# Android.mk — PiAutoSDK
# Integrates libpiauto.so into the AOSP build system (Android.mk / ndk-build).
# Place this file at: vendor/piauto/sdk/Android.mk
#
# Build output:
#   /vendor/lib64/libpiauto.so      (64-bit, arm64-v8a)
#   /vendor/lib/libpiauto.so        (32-bit, armeabi-v7a, if needed)
#
# Usage in AOSP:
#   Add 'libpiauto' to LOCAL_SHARED_LIBRARIES in your app's Android.mk
#   OR add to PRODUCT_PACKAGES in device.mk

LOCAL_PATH := $(call my-dir)

# ============================================================================
# libpiauto_hal.a — HAL static layer
# ============================================================================
include $(CLEAR_VARS)
LOCAL_MODULE    := libpiauto_hal
LOCAL_SRC_FILES := \
    hal/src/usb_detector.cpp \
    hal/src/audio_engine.cpp
LOCAL_C_INCLUDES := \
    $(LOCAL_PATH)/hal/include \
    external/libusb/include \
    external/tinyalsa/include
LOCAL_STATIC_LIBRARIES := libusb libtinyalsa
LOCAL_CPPFLAGS := -std=c++17 -fno-exceptions -fno-rtti -Wall -Wextra
include $(BUILD_STATIC_LIBRARY)

# ============================================================================
# libpiauto_protocol.a — AA + CP protocol static layer
# ============================================================================
include $(CLEAR_VARS)
LOCAL_MODULE    := libpiauto_protocol
LOCAL_SRC_FILES := \
    protocol/android_auto/src/aa_handler.cpp \
    protocol/carplay/src/cp_handler.cpp
LOCAL_C_INCLUDES := \
    $(LOCAL_PATH)/core/include \
    $(LOCAL_PATH)/hal/include \
    $(LOCAL_PATH)/protocol/android_auto/include \
    $(LOCAL_PATH)/protocol/carplay/include \
    external/libusb/include \
    external/boringssl/include
LOCAL_STATIC_LIBRARIES  := libpiauto_hal libssl libcrypto
LOCAL_CPPFLAGS := -std=c++17 -fno-exceptions -fno-rtti -Wall -Wextra
include $(BUILD_STATIC_LIBRARY)

# ============================================================================
# libpiauto_core.a — core SDK static layer
# ============================================================================
include $(CLEAR_VARS)
LOCAL_MODULE    := libpiauto_core
LOCAL_SRC_FILES := \
    core/src/piauto_sdk.cpp \
    core/src/piauto_log.cpp
LOCAL_C_INCLUDES := \
    $(LOCAL_PATH)/core/include \
    $(LOCAL_PATH)/hal/include \
    $(LOCAL_PATH)/protocol/android_auto/include \
    $(LOCAL_PATH)/protocol/carplay/include
LOCAL_STATIC_LIBRARIES := libpiauto_hal libpiauto_protocol
LOCAL_SHARED_LIBRARIES := liblog
LOCAL_CPPFLAGS := -std=c++17 -fno-exceptions -fno-rtti -Wall -Wextra
include $(BUILD_STATIC_LIBRARY)

# ============================================================================
# libpiauto.so — final shared library (JNI + core)
# ============================================================================
include $(CLEAR_VARS)
LOCAL_MODULE           := libpiauto
LOCAL_VENDOR_MODULE    := true       # installs to /vendor/lib64/
LOCAL_SRC_FILES        := jni/src/piauto_jni.cpp
LOCAL_C_INCLUDES       := \
    $(LOCAL_PATH)/core/include \
    $(LOCAL_PATH)/hal/include \
    $(LOCAL_PATH)/protocol/android_auto/include \
    $(LOCAL_PATH)/protocol/carplay/include
LOCAL_STATIC_LIBRARIES := libpiauto_core
LOCAL_SHARED_LIBRARIES := liblog libandroid libnativewindow
LOCAL_CPPFLAGS         := -std=c++17 -fno-exceptions -fno-rtti -Wall -Wextra
LOCAL_LDFLAGS          := -Wl,--version-script,$(LOCAL_PATH)/jni/libpiauto.map.txt
include $(BUILD_SHARED_LIBRARY)
