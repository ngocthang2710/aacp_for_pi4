#!/usr/bin/env bash
# =============================================================================
# debug_log.sh — PiAutoSDK live log monitor and analyzer
#
# Provides focused logcat views for each layer of the SDK stack:
#
#   all         Full PiAutoSDK log stream (all tags)
#   usb         USB detection + AOAP switching events
#   audio       AudioEngine + AudioFlinger + ALSA
#   aa          Android Auto protocol messages
#   cp          CarPlay iAP2 / MFi messages
#   focus       Audio focus changes
#   stats       Periodic SDK stats dump
#   crash       Tombstones + native crashes
#
# Usage:
#   ./scripts/debug_log.sh [layer] [--file log.txt] [--clear]
#
# Examples:
#   ./scripts/debug_log.sh all
#   ./scripts/debug_log.sh audio --file /tmp/audio.log
#   ./scripts/debug_log.sh crash
# =============================================================================
set -euo pipefail

LAYER="${1:-all}"
LOG_FILE=""
CLEAR_LOG=false

shift || true
while [[ $# -gt 0 ]]; do
    case "$1" in
        --file)   LOG_FILE="$2"; shift ;;
        --clear)  CLEAR_LOG=true ;;
        *)        echo "Unknown option: $1"; exit 1 ;;
    esac
    shift
done

if [[ "$CLEAR_LOG" == true ]]; then
    echo "[debug_log] Clearing logcat ..."
    adb logcat -c
fi

# ─────────────────────────────────────────────────────────────────────────────
# Tag filter patterns for each layer
# ─────────────────────────────────────────────────────────────────────────────
declare -A PATTERNS
PATTERNS[all]="PiAutoSDK PiAutoHAL PiAutoAA PiAutoCP PiAutoJNI"
PATTERNS[usb]="PiAutoSDK/usb_detector PiAutoHAL libusb"
PATTERNS[audio]="PiAutoSDK/audio_engine AudioFlinger AudioPolicyService AudioTrack AudioRecord tinyalsa"
PATTERNS[aa]="PiAutoSDK/aa_handler PiAutoAA AndroidAuto"
PATTERNS[cp]="PiAutoSDK/cp_handler PiAutoCP CarPlay iAP2"
PATTERNS[focus]="PiAutoSDK CarAudioService AudioFocus AudioManager"
PATTERNS[stats]="PiAutoSDK"   # stats are INFO level in PiAutoSDK tag
PATTERNS[crash]="DEBUG libc AndroidRuntime FATAL crash_dump"

# Additional adb logcat grep patterns
declare -A GREPS
GREPS[all]="PiAutoSDK"
GREPS[usb]="usb_detector\|AOAP\|hotplug\|VID:0x\|detach\|attach"
GREPS[audio]="audio_engine\|AudioEngine\|ALSA\|underrun\|pcmC\|tinyalsa\|AudioTrack\|AudioRecord"
GREPS[aa]="aa_handler\|AOAP\|TLS\|handshake\|aa_recv\|PING\|PONG\|channel="
GREPS[cp]="cp_handler\|iAP2\|MFi\|SYN\|SYNACK\|CarPlay\|RSA\|sign"
GREPS[focus]="AudioFocus\|AUDIOFOCUS\|focus_change\|ducking\|CarAudio"
GREPS[stats]="stats:\|frames_rx=\|underruns=\|bytes_tx="
GREPS[crash]="SIGSEGV\|SIGABRT\|Fatal signal\|backtrace\|tombstone\|libc.*abort"

PATTERN="${PATTERNS[$LAYER]:-PiAutoSDK}"
GREP_PAT="${GREPS[$LAYER]:-PiAutoSDK}"

# Build logcat tag args
TAG_ARGS=""
for tag in $PATTERN; do
    TAG_ARGS="$TAG_ARGS -s $tag:V"
done
# Always include *:W for warnings/errors from other components
TAG_ARGS="$TAG_ARGS *:W"

echo "======================================"
echo "  PiAutoSDK Debug Monitor: [$LAYER]"
echo "======================================"
echo "  Tags   : $PATTERN"
echo "  Filter : $GREP_PAT"
if [[ -n "$LOG_FILE" ]]; then
    echo "  Output : $LOG_FILE"
fi
echo "  Ctrl+C to stop"
echo ""

# ─────────────────────────────────────────────────────────────────────────────
# Special: stats mode — dumps stats every 5s in a loop
# ─────────────────────────────────────────────────────────────────────────────
if [[ "$LAYER" == "stats" ]]; then
    echo "=== Stats dump loop (every 5s) ==="
    while true; do
        echo ""
        echo "--- $(date '+%H:%M:%S') ---"
        # Dump SDK stats via a custom adb command if the CLI tool is on device
        adb shell "cat /sys/class/usb_device/*/ 2>/dev/null | head -5" || true
        adb shell "dumpsys audio 2>/dev/null | grep -E 'Output|Input|Latency|Underrun' | head -20" || true
        sleep 5
    done
    exit 0
fi

# ─────────────────────────────────────────────────────────────────────────────
# Special: crash mode — look for tombstones
# ─────────────────────────────────────────────────────────────────────────────
if [[ "$LAYER" == "crash" ]]; then
    echo "=== Checking for tombstones ==="
    adb shell ls /data/tombstones/ 2>/dev/null || echo "  No tombstones found."
    echo ""
    echo "=== Live crash monitor ==="
fi

# ─────────────────────────────────────────────────────────────────────────────
# Main logcat stream
# ─────────────────────────────────────────────────────────────────────────────
if [[ -n "$LOG_FILE" ]]; then
    adb logcat -v threadtime $TAG_ARGS 2>/dev/null | grep -E "$GREP_PAT" | tee "$LOG_FILE"
else
    adb logcat -v threadtime $TAG_ARGS 2>/dev/null | grep -E "$GREP_PAT"
fi
