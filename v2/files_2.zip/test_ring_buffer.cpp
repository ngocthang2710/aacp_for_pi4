/*
 * test_ring_buffer.cpp
 *
 * White-box unit tests for the lock-free SPSC ring buffer used inside
 * AudioEngine (audio_engine.cpp). We re-implement the ring buffer header
 * here as a testable standalone unit, since the original lives inside a .cpp.
 *
 * What we test:
 *   1. Basic write/read correctness
 *   2. Wraparound behavior when capacity is exceeded
 *   3. Underrun detection (read from empty buffer)
 *   4. Overrun detection (write to full buffer)
 *   5. Concurrent producer/consumer (one thread each) — data integrity
 */

#include <gtest/gtest.h>
#include <atomic>
#include <cstring>
#include <thread>
#include <vector>
#include <numeric>

// ============================================================================
// Standalone SPSC ring buffer (mirrors audio_engine.cpp implementation)
// ============================================================================
template<size_t CAPACITY>
class SpscRingBuffer {
public:
    // Returns frames written (may be less than count if buffer is full)
    size_t write(const int16_t* src, size_t frames) {
        size_t head = head_.load(std::memory_order_relaxed);
        size_t tail = tail_.load(std::memory_order_acquire);
        size_t avail = CAPACITY - 1 - ((head - tail + CAPACITY) % CAPACITY);
        size_t to_write = std::min(frames, avail);
        for (size_t i = 0; i < to_write; i++) {
            buf_[(head + i) % CAPACITY] = src[i];
        }
        head_.store(head + to_write, std::memory_order_release);
        return to_write;
    }

    // Returns frames read (may be less if buffer is empty)
    size_t read(int16_t* dst, size_t frames) {
        size_t tail = tail_.load(std::memory_order_relaxed);
        size_t head = head_.load(std::memory_order_acquire);
        size_t avail = (head - tail + CAPACITY) % CAPACITY;
        size_t to_read = std::min(frames, avail);
        for (size_t i = 0; i < to_read; i++) {
            dst[i] = buf_[(tail + i) % CAPACITY];
        }
        tail_.store(tail + to_read, std::memory_order_release);
        return to_read;
    }

    size_t available() const {
        size_t h = head_.load(std::memory_order_acquire);
        size_t t = tail_.load(std::memory_order_acquire);
        return (h - t + CAPACITY) % CAPACITY;
    }

    bool empty() const { return available() == 0; }

private:
    static constexpr size_t kCap = CAPACITY;
    alignas(64) std::atomic<size_t> head_{0};
    alignas(64) std::atomic<size_t> tail_{0};
    int16_t buf_[CAPACITY]{};
};

// ============================================================================
// Tests
// ============================================================================
using Buf4096 = SpscRingBuffer<4096>;

TEST(RingBuffer, StartsEmpty) {
    Buf4096 rb;
    EXPECT_TRUE(rb.empty());
    EXPECT_EQ(0u, rb.available());
}

TEST(RingBuffer, WriteAndReadSingleFrame) {
    Buf4096 rb;
    int16_t src[1] = { 1234 };
    int16_t dst[1] = { 0    };

    ASSERT_EQ(1u, rb.write(src, 1));
    ASSERT_EQ(1u, rb.available());
    ASSERT_EQ(1u, rb.read(dst, 1));
    EXPECT_EQ(1234, dst[0]);
    EXPECT_TRUE(rb.empty());
}

TEST(RingBuffer, WriteAndReadMultipleFrames) {
    Buf4096 rb;
    constexpr size_t N = 256;
    std::vector<int16_t> src(N), dst(N, 0);
    std::iota(src.begin(), src.end(), 0);   // 0,1,2,...,255

    ASSERT_EQ(N, rb.write(src.data(), N));
    ASSERT_EQ(N, rb.available());
    ASSERT_EQ(N, rb.read(dst.data(), N));
    EXPECT_EQ(src, dst);
}

TEST(RingBuffer, UnderrunReturnsZero) {
    Buf4096 rb;
    int16_t dst[16] = {};
    // Buffer is empty — read should return 0 (no crash)
    EXPECT_EQ(0u, rb.read(dst, 16));
}

TEST(RingBuffer, OverrunDoesNotCorrupt) {
    Buf4096 rb;
    // Fill the buffer (capacity - 1 frames max)
    constexpr size_t FILL = 4095;
    std::vector<int16_t> src(FILL, 999);
    size_t written = rb.write(src.data(), FILL);
    EXPECT_EQ(FILL, written);

    // Attempt to write 100 more — should be refused or partial
    std::vector<int16_t> extra(100, 777);
    size_t overflow = rb.write(extra.data(), 100);
    EXPECT_EQ(0u, overflow);   // buffer full, nothing written
}

TEST(RingBuffer, WrapAroundPreservesOrder) {
    SpscRingBuffer<8> rb;
    // Write 5 frames, read 3, then write 5 more — forces wraparound
    int16_t s1[] = {1, 2, 3, 4, 5};
    int16_t s2[] = {6, 7, 8, 9, 10};
    int16_t dst[10] = {};

    ASSERT_EQ(5u, rb.write(s1, 5));
    int16_t discard[3] = {};
    ASSERT_EQ(3u, rb.read(discard, 3));   // consume 1,2,3

    ASSERT_EQ(4u, rb.write(s2, 5));       // only 4 fit (buf size=7 usable)

    size_t got = rb.read(dst, 7);
    EXPECT_EQ(4u + 2u, got);              // remaining from s1 (4,5) + 4 from s2
    EXPECT_EQ(4,  dst[0]);
    EXPECT_EQ(5,  dst[1]);
    EXPECT_EQ(6,  dst[2]);
}

TEST(RingBuffer, ConcurrentProducerConsumer) {
    // Single producer, single consumer — verify no data corruption
    static constexpr size_t kBufSize = 65536;
    static constexpr size_t kTotal   = 1000000;
    SpscRingBuffer<kBufSize> rb;

    std::vector<int16_t> produced(kTotal);
    std::iota(produced.begin(), produced.end(), 0);  // 0,1,2,...

    std::vector<int16_t> consumed;
    consumed.reserve(kTotal);

    std::thread producer([&]{
        size_t sent = 0;
        while (sent < kTotal) {
            size_t batch = std::min<size_t>(256, kTotal - sent);
            size_t w = rb.write(produced.data() + sent, batch);
            sent += w;
            if (w == 0) std::this_thread::yield();
        }
    });

    std::thread consumer([&]{
        int16_t tmp[256];
        while (consumed.size() < kTotal) {
            size_t r = rb.read(tmp, 256);
            for (size_t i = 0; i < r; i++) consumed.push_back(tmp[i]);
            if (r == 0) std::this_thread::yield();
        }
    });

    producer.join();
    consumer.join();

    ASSERT_EQ(kTotal, consumed.size());
    for (size_t i = 0; i < kTotal; i++) {
        // int16_t wraps — compare modulo 65536
        EXPECT_EQ(static_cast<int16_t>(i), consumed[i])
            << "Mismatch at index " << i;
        if (static_cast<int16_t>(i) != consumed[i]) break;  // stop early on failure
    }
}
