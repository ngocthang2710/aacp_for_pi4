#!/usr/bin/env bash
# =============================================================================
# install.sh — Push PiAutoSDK build artifacts to Android device via adb
#
# What it does:
#   1. Push libpiauto.so to /vendor/lib64/
#   2. Push config files to /vendor/etc/piauto/
#   3. Push Java AAR/classes to AOSP overlay path (if built)
#   4. Restart audioserver + HU app to pick up new .so
#   5. Run basic smoke test via logcat
#
# Usage:
#   ./scripts/install.sh                 # install release build
#   ./scripts/install.sh --debug         # install debug build
#   ./scripts/install.sh --verify-only   # only verify (no push)
# =============================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SDK_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
BUILD_ANDROID="$SDK_ROOT/build/android"

MODE="release"
VERIFY_ONLY=false

for arg in "$@"; do
    case "$arg" in
        --debug)       MODE="debug" ;;
        --verify-only) VERIFY_ONLY=true ;;
    esac
done

# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────
check_device() {
    if ! adb get-state &>/dev/null; then
        echo "[ERROR] No adb device connected. Run: adb devices"
        exit 1
    fi
    DEVICE=$(adb get-state)
    if [[ "$DEVICE" != "device" ]]; then
        echo "[ERROR] Device not ready (state: $DEVICE)"
        exit 1
    fi
    echo "[INFO] Device: $(adb shell getprop ro.product.model | tr -d '\r')"
    echo "[INFO] Android: $(adb shell getprop ro.build.version.release | tr -d '\r')"
}

push_file() {
    local src="$1" dst="$2" perms="${3:-644}"
    echo "  Pushing: $(basename "$src") → $dst"
    adb push "$src" "$dst"
    adb shell chmod "$perms" "$dst"
}

# ─────────────────────────────────────────────────────────────────────────────
# verify_only — check what's currently on the device
# ─────────────────────────────────────────────────────────────────────────────
verify_device() {
    echo ""
    echo "=== Verify: /vendor/lib64/libpiauto.so ==="
    adb shell ls -la /vendor/lib64/libpiauto.so 2>/dev/null || echo "  [MISSING]"

    echo ""
    echo "=== Verify: /vendor/etc/piauto/ ==="
    adb shell ls -la /vendor/etc/piauto/ 2>/dev/null || echo "  [MISSING]"

    echo ""
    echo "=== Verify: Loaded in process (if app running) ==="
    local pid
    pid=$(adb shell pidof com.piauto.app 2>/dev/null | tr -d '\r' || echo "")
    if [[ -n "$pid" ]]; then
        adb shell grep libpiauto /proc/"$pid"/maps 2>/dev/null || echo "  [not mapped]"
    else
        echo "  com.piauto.app not running"
    fi

    echo ""
    echo "=== Verify: SDK logcat (last 20 lines) ==="
    adb logcat -d -s PiAutoSDK | tail -20 || true
}

if [[ "$VERIFY_ONLY" == true ]]; then
    check_device
    verify_device
    exit 0
fi

# ─────────────────────────────────────────────────────────────────────────────
# Check that libpiauto.so exists
# ─────────────────────────────────────────────────────────────────────────────
LIB_PATH="$BUILD_ANDROID/libpiauto.so"
if [[ ! -f "$LIB_PATH" ]]; then
    echo "[ERROR] libpiauto.so not found at: $LIB_PATH"
    echo "  Run: ./scripts/build.sh android"
    exit 1
fi

# ─────────────────────────────────────────────────────────────────────────────
# Install
# ─────────────────────────────────────────────────────────────────────────────
check_device
echo ""
echo "=== PiAutoSDK Install ($MODE) ==="

echo "[1/4] Remounting vendor partition ..."
adb root
sleep 1
adb remount

echo ""
echo "[2/4] Pushing shared library ..."
adb shell mkdir -p /vendor/lib64
push_file "$LIB_PATH" /vendor/lib64/libpiauto.so 644

echo ""
echo "[3/4] Pushing config files ..."
adb shell mkdir -p /vendor/etc/piauto
for cfg in "$SDK_ROOT/configs"/*.xml; do
    push_file "$cfg" "/vendor/etc/piauto/$(basename "$cfg")" 644
done

# Push dev certs if they exist
if [[ -d "$SDK_ROOT/certs" ]]; then
    echo ""
    echo "[3b] Pushing dev certificates ..."
    for cert in "$SDK_ROOT/certs"/*.pem; do
        push_file "$cert" "/vendor/etc/piauto/$(basename "$cert")" 640
    done
    adb shell chown -R audioserver:audioserver /vendor/etc/piauto/
fi

echo ""
echo "[4/4] Restarting audio services ..."
# Stop the HU app if running
adb shell am force-stop com.piauto.app 2>/dev/null || true
# Restart audioserver to reload HAL / .so
adb shell pkill -f audioserver 2>/dev/null || true
sleep 2

echo ""
echo "=== Installation complete ==="
verify_device

echo ""
echo "=== Tailing logcat for PiAutoSDK (Ctrl+C to stop) ==="
echo "  Tip: Filter pattern = 'PiAutoSDK|libpiauto'"
echo ""
adb logcat -c   # clear old log
adb logcat -s "PiAutoSDK" | head -50 || true
