/*
 * PiAutoSDK.java
 *
 * Java wrapper for the PiAutoSDK native C++ library.
 * Responsibilities:
 *  - Load libpiauto.so via System.loadLibrary()
 *  - Declare native methods that map to piauto_jni.cpp
 *  - Provide a clean Java API with Builder pattern for configuration
 *  - Bridge C++ callbacks → Android Handler/Looper (main thread delivery)
 *  - Manage AudioTrack (media/nav/voice playback) and AudioRecord (mic capture)
 *  - Handle CarAudioManager focus requests on behalf of the SDK
 *
 * Threading model:
 *  - Public methods: callable from any thread (internally thread-safe)
 *  - Callbacks: delivered on the thread that called init() (usually main thread via Handler)
 *  - AudioTrack write loop: runs on a dedicated HandlerThread
 */

package com.piauto.sdk;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.MediaRecorder;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.util.Log;

import java.util.concurrent.atomic.AtomicBoolean;

public final class PiAutoSDK {

    private static final String TAG = "PiAutoSDK";
    private static final String LIB_NAME = "piauto";

    // -----------------------------------------------------------------------
    // Static initializer — loads the native .so once per process
    // -----------------------------------------------------------------------
    static {
        System.loadLibrary(LIB_NAME);
    }

    // -----------------------------------------------------------------------
    // Callback interface — implemented by the host application
    // -----------------------------------------------------------------------
    public interface Callback {
        /** Called when connection state changes (see STATE_* constants). */
        void onConnectionStateChanged(int state, int protocol);

        /** Called when audio PCM data is available for playback (channel 0=media,1=nav,2=voice). */
        void onAudioData(int channel, byte[] pcmData, int sampleRate, int channelCount);

        /** Called when a H.264 NAL unit is ready for the video renderer. */
        void onVideoFrame(byte[] nalUnit, long presentationTimeUs);

        /** Called when navigation instruction JSON is received from the phone. */
        void onNavigationData(String json);
    }

    // -----------------------------------------------------------------------
    // Connection state constants (mirror PiAutoConnectionState in C++)
    // -----------------------------------------------------------------------
    public static final int STATE_IDLE           = 0;
    public static final int STATE_DETECTING      = 1;
    public static final int STATE_AUTHENTICATING = 2;
    public static final int STATE_NEGOTIATING    = 3;
    public static final int STATE_CONNECTED      = 4;
    public static final int STATE_SUSPENDED      = 5;
    public static final int STATE_DISCONNECTING  = 6;
    public static final int STATE_ERROR          = 7;

    // Protocol constants
    public static final int PROTOCOL_NONE         = 0;
    public static final int PROTOCOL_ANDROID_AUTO = 1;
    public static final int PROTOCOL_CARPLAY      = 2;

    // Log level constants (mirror piauto_log.h)
    public static final int LOG_ERROR   = 1;
    public static final int LOG_WARN    = 2;
    public static final int LOG_INFO    = 3;
    public static final int LOG_DEBUG   = 4;
    public static final int LOG_VERBOSE = 5;

    // -----------------------------------------------------------------------
    // Builder — used to configure and instantiate PiAutoSDK
    // -----------------------------------------------------------------------
    public static final class Builder {
        private final Context context;
        private Callback callback;
        private int screenWidth  = 1920;
        private int screenHeight = 720;
        private int screenDpi    = 160;
        private int targetFps    = 60;
        private boolean nightMode = false;
        private int logLevel = LOG_INFO;

        public Builder(Context context) {
            this.context = context.getApplicationContext();
        }

        public Builder setCallback(Callback cb)           { this.callback = cb;           return this; }
        public Builder setScreenWidth(int w)              { this.screenWidth = w;          return this; }
        public Builder setScreenHeight(int h)             { this.screenHeight = h;         return this; }
        public Builder setScreenDpi(int dpi)              { this.screenDpi = dpi;          return this; }
        public Builder setTargetFps(int fps)              { this.targetFps = fps;          return this; }
        public Builder setNightMode(boolean night)        { this.nightMode = night;        return this; }
        public Builder setLogLevel(int level)             { this.logLevel = level;         return this; }

        public PiAutoSDK build() {
            if (callback == null) throw new IllegalStateException("Callback must be set");
            return new PiAutoSDK(this);
        }
    }

    // -----------------------------------------------------------------------
    // Internal fields
    // -----------------------------------------------------------------------
    private final Context       mContext;
    private final Callback      mCallback;
    private final Handler       mMainHandler;
    private final HandlerThread mAudioThread;
    private final Handler       mAudioHandler;
    private final AtomicBoolean mStarted = new AtomicBoolean(false);

    // AudioTrack instances per channel (0=media, 1=nav, 2=voice)
    private AudioTrack[] mAudioTracks = new AudioTrack[3];

    // AudioRecord for mic capture
    private AudioRecord mAudioRecord;
    private Thread      mMicThread;
    private volatile boolean mMicRunning = false;

    // AudioManager for focus requests
    private AudioManager        mAudioManager;
    private AudioManager.OnAudioFocusChangeListener mFocusListener;

    // -----------------------------------------------------------------------
    // Constructor (private — use Builder)
    // -----------------------------------------------------------------------
    private PiAutoSDK(Builder b) {
        mContext     = b.context;
        mCallback    = b.callback;
        mMainHandler = new Handler(Looper.getMainLooper());

        // Dedicated audio write thread (avoids blocking main thread)
        mAudioThread = new HandlerThread("PiAutoAudio", android.os.Process.THREAD_PRIORITY_URGENT_AUDIO);
        mAudioThread.start();
        mAudioHandler = new Handler(mAudioThread.getLooper());

        mAudioManager = (AudioManager) mContext.getSystemService(Context.AUDIO_SERVICE);

        // Create the native SDK instance
        nativeInit(b.screenWidth, b.screenHeight, b.screenDpi, b.targetFps, b.nightMode);
        nativeSetLogLevel(b.logLevel);

        Log.i(TAG, "PiAutoSDK initialized. Version: " + nativeGetVersion());
    }

    // -----------------------------------------------------------------------
    // Public lifecycle API
    // -----------------------------------------------------------------------

    /**
     * Start USB detection and protocol handling.
     * Safe to call from any thread.
     */
    public void start() {
        if (!mStarted.compareAndSet(false, true)) {
            Log.w(TAG, "start() called but already started");
            return;
        }
        requestAudioFocus();
        nativeStart();
        Log.i(TAG, "PiAutoSDK started");
    }

    /**
     * Stop all activity and release USB/audio resources.
     * Idempotent — safe to call multiple times.
     */
    public void stop() {
        if (!mStarted.compareAndSet(true, false)) return;
        nativeStop();
        stopMicCapture();
        releaseAudioFocus();
        releaseAudioTracks();
        Log.i(TAG, "PiAutoSDK stopped");
    }

    /**
     * Permanently destroy this instance. Do not use after calling destroy().
     */
    public void destroy() {
        stop();
        nativeDestroy();
        mAudioThread.quitSafely();
        Log.i(TAG, "PiAutoSDK destroyed");
    }

    // -----------------------------------------------------------------------
    // Input API
    // -----------------------------------------------------------------------

    /**
     * Send a touch event to the phone.
     * @param action 0=DOWN, 1=MOVE, 2=UP
     * @param x      touch X in display pixels
     * @param y      touch Y in display pixels
     * @param id     pointer/finger id (for multi-touch)
     */
    public void sendTouchEvent(int action, float x, float y, int id) {
        nativeSendTouch(action, x, y, id);
    }

    /**
     * Send a hard-key event (e.g. steering wheel button).
     * @param keyCode  KEYCODE_* from android.view.KeyEvent
     * @param action   0=DOWN, 1=UP
     */
    public void sendKeyEvent(int keyCode, int action) {
        nativeSendKey(keyCode, action);
    }

    // -----------------------------------------------------------------------
    // Audio API
    // -----------------------------------------------------------------------

    /**
     * Set playback volume for a channel.
     * @param channel 0=media, 1=nav, 2=voice
     * @param volume  0.0f – 1.0f
     */
    public void setVolume(int channel, float volume) {
        nativeSetVolume(channel, volume);
        if (mAudioTracks[channel] != null) {
            mAudioTracks[channel].setVolume(volume);
        }
    }

    /** Get current connection state as one of the STATE_* constants. */
    public int getState() {
        return nativeGetState();
    }

    /** Get the SDK version string (e.g. "1.0.0"). */
    public String getVersion() {
        return nativeGetVersion();
    }

    // -----------------------------------------------------------------------
    // Callbacks from native — called on C++ recv threads, marshalled to main
    // NOTE: these method names MUST match piauto_jni.cpp methodID lookups
    // -----------------------------------------------------------------------

    /** Called by JNI when connection state changes. Do NOT rename. */
    @SuppressWarnings("unused")
    private void onNativeStateChanged(final int state, final int protocol) {
        mMainHandler.post(() -> mCallback.onConnectionStateChanged(state, protocol));

        // When connected, ensure AudioTrack instances are ready
        if (state == STATE_CONNECTED) {
            mAudioHandler.post(this::ensureAudioTracksCreated);
        }
        // When disconnected, release audio resources
        if (state == STATE_IDLE || state == STATE_ERROR) {
            mAudioHandler.post(this::releaseAudioTracks);
            stopMicCapture();
        }
    }

    /** Called by JNI when PCM audio arrives. Do NOT rename. */
    @SuppressWarnings("unused")
    private void onNativeAudioData(final int channel, final byte[] pcm,
                                   final int sampleRate, final int chCount) {
        // Write to AudioTrack on the audio handler thread
        mAudioHandler.post(() -> {
            writeToAudioTrack(channel, pcm, sampleRate, chCount);
        });
        // Also deliver raw PCM to app callback (for custom renderers)
        mMainHandler.post(() -> mCallback.onAudioData(channel, pcm, sampleRate, chCount));
    }

    /** Called by JNI when a video NAL unit arrives. Do NOT rename. */
    @SuppressWarnings("unused")
    private void onNativeVideoFrame(final byte[] nal, final long pts) {
        mMainHandler.post(() -> mCallback.onVideoFrame(nal, pts));
    }

    /** Called by JNI when navigation JSON arrives. Do NOT rename. */
    @SuppressWarnings("unused")
    private void onNativeNavData(final String json) {
        mMainHandler.post(() -> mCallback.onNavigationData(json));
    }

    // -----------------------------------------------------------------------
    // Audio internals
    // -----------------------------------------------------------------------

    /**
     * ensureAudioTracksCreated — idempotently creates one AudioTrack per channel.
     *
     * Channel mapping:
     *   0 = MEDIA      (AudioAttributes.USAGE_MEDIA)
     *   1 = NAVIGATION (AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
     *   2 = VOICE_CALL (AudioAttributes.USAGE_VOICE_COMMUNICATION)
     */
    private void ensureAudioTracksCreated() {
        int[] usages = {
            AudioAttributes.USAGE_MEDIA,
            AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE,
            AudioAttributes.USAGE_VOICE_COMMUNICATION
        };
        for (int ch = 0; ch < 3; ch++) {
            if (mAudioTracks[ch] != null) continue;

            AudioAttributes attrs = new AudioAttributes.Builder()
                .setUsage(usages[ch])
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build();

            AudioFormat fmt = new AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(48000)
                .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                .build();

            int minBuf = AudioTrack.getMinBufferSize(48000,
                AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT);

            mAudioTracks[ch] = new AudioTrack.Builder()
                .setAudioAttributes(attrs)
                .setAudioFormat(fmt)
                .setBufferSizeInBytes(minBuf * 4)   // 4x min for low-latency safety
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build();

            mAudioTracks[ch].play();
            Log.d(TAG, "AudioTrack[" + ch + "] created, minBuf=" + minBuf);
        }

        // Start mic capture when connected
        startMicCapture();
    }

    /**
     * writeToAudioTrack — writes PCM bytes to the correct AudioTrack.
     * Recreates the track if sample rate or channel count changed.
     */
    private void writeToAudioTrack(int channel, byte[] pcm, int sampleRate, int chCount) {
        if (channel < 0 || channel >= mAudioTracks.length) return;
        AudioTrack track = mAudioTracks[channel];
        if (track == null || track.getState() != AudioTrack.STATE_INITIALIZED) return;

        // Note: full implementation would check sampleRate/chCount and recreate if changed
        int written = track.write(pcm, 0, pcm.length, AudioTrack.WRITE_NON_BLOCKING);
        if (written < 0) {
            Log.w(TAG, "AudioTrack[" + channel + "] write error: " + written);
        }
    }

    private void releaseAudioTracks() {
        for (int i = 0; i < mAudioTracks.length; i++) {
            if (mAudioTracks[i] != null) {
                mAudioTracks[i].stop();
                mAudioTracks[i].release();
                mAudioTracks[i] = null;
            }
        }
    }

    // -----------------------------------------------------------------------
    // Mic capture — sends PCM data to C++ layer via AudioRecord
    // -----------------------------------------------------------------------

    private void startMicCapture() {
        if (mMicRunning) return;
        final int sampleRate   = 16000;     // AA/CP mic: 16kHz mono
        final int channelMask  = AudioFormat.CHANNEL_IN_MONO;
        final int encoding     = AudioFormat.ENCODING_PCM_16BIT;
        int minBuf = AudioRecord.getMinBufferSize(sampleRate, channelMask, encoding);

        try {
            mAudioRecord = new AudioRecord.Builder()
                .setAudioSource(MediaRecorder.AudioSource.MIC)
                .setAudioFormat(new AudioFormat.Builder()
                    .setEncoding(encoding)
                    .setSampleRate(sampleRate)
                    .setChannelMask(channelMask)
                    .build())
                .setBufferSizeInBytes(minBuf * 2)
                .build();

            if (mAudioRecord.getState() != AudioRecord.STATE_INITIALIZED) {
                Log.e(TAG, "AudioRecord failed to initialize");
                return;
            }
        } catch (SecurityException e) {
            Log.e(TAG, "Mic permission denied: " + e.getMessage());
            return;
        }

        mMicRunning = true;
        mAudioRecord.startRecording();

        mMicThread = new Thread(() -> {
            byte[] buf = new byte[minBuf];
            while (mMicRunning) {
                int read = mAudioRecord.read(buf, 0, buf.length);
                if (read > 0) {
                    // Send raw PCM up to C++ layer (no JNI method currently —
                    // hook nativeSendMicData() here if C++ layer needs it)
                    // nativeSendMicData(buf, read, sampleRate, 1);
                }
            }
        }, "PiAutoMic");
        mMicThread.setPriority(Thread.MAX_PRIORITY - 1);
        mMicThread.start();
        Log.i(TAG, "Mic capture started @" + sampleRate + "Hz");
    }

    private void stopMicCapture() {
        mMicRunning = false;
        if (mMicThread != null) {
            try { mMicThread.join(500); } catch (InterruptedException ignored) {}
            mMicThread = null;
        }
        if (mAudioRecord != null) {
            mAudioRecord.stop();
            mAudioRecord.release();
            mAudioRecord = null;
        }
    }

    // -----------------------------------------------------------------------
    // Audio focus (CarAudioManager / AudioManager)
    // -----------------------------------------------------------------------

    private void requestAudioFocus() {
        mFocusListener = focusChange -> {
            Log.i(TAG, "AudioFocus changed: " + focusChange);
            if (focusChange == AudioManager.AUDIOFOCUS_LOSS) {
                // Pause all channels (the phone app is responsible for actual media)
                nativeSetVolume(0, 0.0f);
            } else if (focusChange == AudioManager.AUDIOFOCUS_GAIN) {
                nativeSetVolume(0, 1.0f);
            }
        };

        AudioAttributes attrs = new AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .build();

        int result = mAudioManager.requestAudioFocus(
            new AudioManager.AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setAudioAttributes(attrs)
                .setOnAudioFocusChangeListener(mFocusListener, mMainHandler)
                .setAcceptsDelayedFocusGain(true)
                .build());

        Log.i(TAG, "AudioFocus request result: " +
            (result == AudioManager.AUDIOFOCUS_REQUEST_GRANTED ? "GRANTED" : "DENIED/DELAYED"));
    }

    private void releaseAudioFocus() {
        if (mFocusListener != null) {
            // Note: full impl would cache AudioFocusRequest object for abandon
            mFocusListener = null;
        }
    }

    // -----------------------------------------------------------------------
    // Native method declarations (implemented in piauto_jni.cpp)
    // -----------------------------------------------------------------------
    private native void   nativeInit(int screenW, int screenH, int screenDpi,
                                     int fps, boolean nightMode);
    private native void   nativeStart();
    private native void   nativeStop();
    private native void   nativeDestroy();
    private native void   nativeSendTouch(int action, float x, float y, int id);
    private native void   nativeSendKey(int keyCode, int action);
    private native void   nativeSetVolume(int channel, float volume);
    private native int    nativeGetState();
    private native String nativeGetVersion();
    private native void   nativeSetLogLevel(int level);
}
