#!/usr/bin/env bash
# =============================================================================
# gen_certs.sh — Generate development TLS and MFi certificates for PiAutoSDK
#
# ⚠  DEVELOPMENT USE ONLY — these are self-signed and will NOT be accepted
#    by production Android Auto or real iPhones without proper MFi licensing.
#
# Outputs (written to /vendor/etc/piauto/ on device):
#   hu_cert.pem      — Head Unit TLS certificate (for Android Auto)
#   hu_key.pem       — Head Unit TLS private key
#   hu_ca.pem        — Self-signed CA cert
#   mfi_cert.pem     — Fake MFi auth certificate (for CarPlay dev mode)
#   mfi_key.pem      — MFi auth private key
#
# Usage:
#   ./scripts/gen_certs.sh                  # generate to ./certs/
#   ./scripts/gen_certs.sh --push           # generate + adb push to device
# =============================================================================
set -euo pipefail

CERT_DIR="$(dirname "$0")/../certs"
PUSH=false

for arg in "$@"; do
    [[ "$arg" == "--push" ]] && PUSH=true
done

mkdir -p "$CERT_DIR"
cd "$CERT_DIR"

echo "=== Generating PiAutoSDK development certificates ==="

# ─────────────────────────────────────────────────────────────────────────────
# 1. Root CA (self-signed, 10 year validity)
# ─────────────────────────────────────────────────────────────────────────────
echo "[1/4] Generating root CA ..."
openssl genpkey -algorithm EC -pkeyopt ec_paramgen_curve:P-256 -out ca_key.pem
openssl req -new -x509 -key ca_key.pem -out hu_ca.pem -days 3650 \
    -subj "/C=JP/ST=Tokyo/O=PiAuto Inc./CN=PiAuto Dev CA"

# ─────────────────────────────────────────────────────────────────────────────
# 2. Head Unit TLS certificate (Android Auto)
#    Subject Alt Name: HU serial + hostname for TLS verification
# ─────────────────────────────────────────────────────────────────────────────
echo "[2/4] Generating HU TLS certificate ..."
openssl genpkey -algorithm EC -pkeyopt ec_paramgen_curve:P-256 -out hu_key.pem

openssl req -new -key hu_key.pem -out hu_csr.pem \
    -subj "/C=JP/ST=Tokyo/O=PiAuto Inc./CN=PI4HU-0001" \
    -addext "subjectAltName=DNS:piauto.local,DNS:PI4HU-0001"

openssl x509 -req -in hu_csr.pem -CA hu_ca.pem -CAkey ca_key.pem \
    -CAcreateserial -out hu_cert.pem -days 3650 \
    -extfile <(printf "subjectAltName=DNS:piauto.local,DNS:PI4HU-0001\n")

rm -f hu_csr.pem

# ─────────────────────────────────────────────────────────────────────────────
# 3. MFi auth certificate (CarPlay — dev/fake mode)
#    Real MFi chips use RSA-2048 or ECDSA-256. We use RSA-2048 here.
#    The cp_handler.cpp software fallback path uses this cert + key.
# ─────────────────────────────────────────────────────────────────────────────
echo "[3/4] Generating MFi auth key pair ..."
openssl genpkey -algorithm RSA -pkeyopt rsa_keygen_bits:2048 -out mfi_key.pem

openssl req -new -x509 -key mfi_key.pem -out mfi_cert.pem -days 3650 \
    -subj "/C=JP/O=PiAuto Dev/CN=PiAuto MFi Dev Cert"

# ─────────────────────────────────────────────────────────────────────────────
# 4. Verify
# ─────────────────────────────────────────────────────────────────────────────
echo "[4/4] Verifying certificates ..."
openssl verify -CAfile hu_ca.pem hu_cert.pem && echo "  HU cert OK"
openssl x509 -noout -text -in hu_cert.pem | grep "Subject:"
openssl x509 -noout -text -in mfi_cert.pem | grep "Subject:"

echo ""
echo "=== Certificate files ==="
ls -la "$CERT_DIR"/*.pem

# ─────────────────────────────────────────────────────────────────────────────
# Optional: push to device
# ─────────────────────────────────────────────────────────────────────────────
if [[ "$PUSH" == true ]]; then
    echo ""
    echo "=== Pushing certificates to device ==="
    adb root
    adb remount

    DEVICE_CERT_DIR="/vendor/etc/piauto"
    adb shell mkdir -p "$DEVICE_CERT_DIR"

    for f in hu_cert.pem hu_key.pem hu_ca.pem mfi_cert.pem mfi_key.pem; do
        adb push "$CERT_DIR/$f" "$DEVICE_CERT_DIR/$f"
        adb shell chmod 640 "$DEVICE_CERT_DIR/$f"
        echo "  Pushed: $f"
    done

    # Certs should be owned by the vendor audio HAL uid
    adb shell chown -R audioserver:audioserver "$DEVICE_CERT_DIR"
    echo "  Owner set to audioserver"

    echo ""
    echo "=== Verifying on device ==="
    adb shell ls -la "$DEVICE_CERT_DIR"
fi

echo ""
echo "[gen_certs.sh] DONE."
