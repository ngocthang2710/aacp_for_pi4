#!/usr/bin/env bash
# =============================================================================
# package_sdk.sh — PiAutoSDK OEM Distribution Packaging
#
# Đóng gói SDK thành bộ phân phối chuyên nghiệp cho OEM/khách hàng.
# Khách hàng KHÔNG nhận được source code — chỉ nhận binary + public headers.
#
# Output structure:
#   piauto-sdk-<version>-<target>-<date>/
#   ├── lib/
#   │   ├── arm64-v8a/libpiauto.so      ← Shared library (stripped)
#   │   ├── arm64-v8a/libpiauto.so.dbg  ← Debug symbols (tách riêng)
#   │   └── arm64-v8a/libpiauto.a       ← Static lib (nếu có)
#   ├── include/
#   │   ├── piauto_sdk.h                ← Public API (chỉ 4 headers này)
#   │   ├── piauto_types.h
#   │   ├── piauto_callbacks.h
#   │   └── piauto_log.h
#   ├── java/
# java/piauto-sdk-version.aar    -- Android Archive (Java wrapper)
#   ├── configs/
#   │   ├── audio_policy_configuration.xml
#   │   ├── car_audio_configuration.xml
#   │   └── device.mk.snippet
#   ├── docs/
#   │   ├── ARCHITECTURE.md
#   │   ├── INTEGRATION_GUIDE.md
#   │   ├── CHANGELOG.md
#   │   └── API_REFERENCE.md
#   ├── samples/
#   │   └── PiAutoSampleApp/            ← Minimal sample app (no SDK source)
#   ├── licenses/
#   │   ├── LICENSE.txt                 ← OEM license
#   │   └── THIRD_PARTY_LICENSES.txt    ← libusb, OpenSSL, tinyalsa
#   └── README.md
#
# Usage:
#   ./scripts/package_sdk.sh [options]
#
# Options:
#   --target   arm64-v8a | x86_64 | all   (default: arm64-v8a)
#   --type     release | debug | both      (default: release)
#   --version  override version string     (default: from CMakeLists.txt)
#   --oem      OEM/customer name           (e.g. "Toyota" → embedded in package)
#   --sign     sign the .so with openssl   (requires SIGN_KEY env var)
#   --no-aar   skip AAR generation
#   --out      output directory            (default: ./dist/)
#
# Examples:
#   ./scripts/package_sdk.sh
#   ./scripts/package_sdk.sh --oem "Denso" --type both --sign
#   ./scripts/package_sdk.sh --target all --out /tmp/release/
# =============================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SDK_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"

# ─── Defaults ────────────────────────────────────────────────────────────────
TARGET="arm64-v8a"
BUILD_TYPE="release"
OEM_NAME=""
DO_SIGN=false
BUILD_AAR=true
OUT_DIR="$SDK_ROOT/dist"

# Parse CLI args
while [[ $# -gt 0 ]]; do
    case "$1" in
        --target)  TARGET="$2";    shift 2 ;;
        --type)    BUILD_TYPE="$2"; shift 2 ;;
        --version) FORCE_VER="$2"; shift 2 ;;
        --oem)     OEM_NAME="$2";  shift 2 ;;
        --sign)    DO_SIGN=true;   shift   ;;
        --no-aar)  BUILD_AAR=false; shift  ;;
        --out)     OUT_DIR="$2";   shift 2 ;;
        *) echo "[ERROR] Unknown option: $1"; exit 1 ;;
    esac
done

# ─── Version extraction from CMakeLists.txt ───────────────────────────────────
VERSION="${FORCE_VER:-}"
if [[ -z "$VERSION" ]]; then
    VERSION=$(grep -m1 'project(PiAutoSDK VERSION' "$SDK_ROOT/CMakeLists.txt" \
              | sed 's/.*VERSION \([0-9.]*\).*/\1/')
fi
DATE=$(date '+%Y%m%d')
TARGETS=()
[[ "$TARGET" == "all" ]] && TARGETS=(arm64-v8a x86_64) || TARGETS=("$TARGET")

echo "╔══════════════════════════════════════════════════════╗"
echo "║         PiAutoSDK OEM Packaging Tool                 ║"
echo "╠══════════════════════════════════════════════════════╣"
echo "║  Version  : $VERSION"
echo "║  Target   : ${TARGETS[*]}"
echo "║  Type     : $BUILD_TYPE"
[[ -n "$OEM_NAME" ]] && echo "║  OEM      : $OEM_NAME"
echo "║  Sign     : $DO_SIGN"
echo "║  Output   : $OUT_DIR"
echo "╚══════════════════════════════════════════════════════╝"
echo ""

# ─────────────────────────────────────────────────────────────────────────────
# STEP 1: Build for each target
# ─────────────────────────────────────────────────────────────────────────────
echo "▶ Step 1/6: Building binaries ..."

build_for_target() {
    local arch="$1"
    local btype="$2"   # release | debug
    local build_dir="$SDK_ROOT/build/${arch}_${btype}"

    if [[ -z "${ANDROID_NDK:-}" ]]; then
        echo "  [WARN] ANDROID_NDK not set — skipping real build, using stub binary"
        mkdir -p "$build_dir"
        # Create a stub .so for packaging demo (replace with real build in CI)
        echo "STUB: replace with real NDK build" > "$build_dir/libpiauto.so"
        echo "STUB: debug symbols" > "$build_dir/libpiauto.so.dbg"
        return
    fi

    mkdir -p "$build_dir"
    CMAKE_BUILD_TYPE="Release"
    [[ "$btype" == "debug" ]] && CMAKE_BUILD_TYPE="RelWithDebInfo"

    cmake "$SDK_ROOT" \
        -B "$build_dir" \
        -GNinja \
        -DCMAKE_TOOLCHAIN_FILE="$ANDROID_NDK/build/cmake/android.toolchain.cmake" \
        -DANDROID_ABI="$arch" \
        -DANDROID_PLATFORM=android-35 \
        -DCMAKE_BUILD_TYPE="$CMAKE_BUILD_TYPE" \
        -DPIAUTO_BUILD_TESTS=OFF \
        -DPIAUTO_ANDROID_BUILD=ON \
        -DCMAKE_EXPORT_COMPILE_COMMANDS=OFF \
        -DPIAUTO_VERSION_STRING="$VERSION" \
        -DPIAUTO_OEM_NAME="$OEM_NAME" \
        > "$build_dir/cmake.log" 2>&1

    ninja -C "$build_dir" -j"$(nproc)" libpiauto >> "$build_dir/cmake.log" 2>&1

    # Strip debug info into separate .dbg file
    local SO="$build_dir/libpiauto.so"
    if command -v llvm-objcopy &>/dev/null; then
        llvm-objcopy --only-keep-debug "$SO" "$SO.dbg"
        llvm-objcopy --strip-debug --strip-unneeded "$SO"
        llvm-objcopy --add-gnu-debuglink="$SO.dbg" "$SO"
        echo "  ✓ Debug symbols stripped → libpiauto.so.dbg"
    elif command -v objcopy &>/dev/null; then
        objcopy --only-keep-debug "$SO" "$SO.dbg"
        strip --strip-debug --strip-unneeded "$SO"
        objcopy --add-gnu-debuglink="$SO.dbg" "$SO"
        echo "  ✓ Debug symbols stripped → libpiauto.so.dbg"
    else
        echo "  [WARN] objcopy not found — .so not stripped"
    fi

    echo "  ✓ Built: $arch ($btype) → $SO"
}

BUILD_TYPES=()
[[ "$BUILD_TYPE" == "both" ]] && BUILD_TYPES=(release debug) || BUILD_TYPES=("$BUILD_TYPE")

for arch in "${TARGETS[@]}"; do
    for btype in "${BUILD_TYPES[@]}"; do
        build_for_target "$arch" "$btype"
    done
done

# ─────────────────────────────────────────────────────────────────────────────
# STEP 2: Create package directory structure
# ─────────────────────────────────────────────────────────────────────────────
echo ""
echo "▶ Step 2/6: Creating package structure ..."

PKG_NAME="piauto-sdk-${VERSION}-${DATE}"
[[ -n "$OEM_NAME" ]] && PKG_NAME="piauto-sdk-${VERSION}-${OEM_NAME,,}-${DATE}"
PKG_DIR="$OUT_DIR/$PKG_NAME"

rm -rf "$PKG_DIR"
mkdir -p "$PKG_DIR"/{lib,include,java,configs,docs,samples,licenses}

for arch in "${TARGETS[@]}"; do
    mkdir -p "$PKG_DIR/lib/$arch"
done

echo "  ✓ Package dir: $PKG_DIR"

# ─────────────────────────────────────────────────────────────────────────────
# STEP 3: Copy binaries (NOT source)
# ─────────────────────────────────────────────────────────────────────────────
echo ""
echo "▶ Step 3/6: Copying binaries ..."

for arch in "${TARGETS[@]}"; do
    for btype in "${BUILD_TYPES[@]}"; do
        build_dir="$SDK_ROOT/build/${arch}_${btype}"
        so="$build_dir/libpiauto.so"
        dbg="$build_dir/libpiauto.so.dbg"

        if [[ -f "$so" ]]; then
            if [[ "$btype" == "release" ]]; then
                cp "$so" "$PKG_DIR/lib/$arch/libpiauto.so"
                echo "  ✓ lib/$arch/libpiauto.so"
            else
                # Debug build goes into a debug/ subfolder
                mkdir -p "$PKG_DIR/lib/$arch/debug"
                cp "$so" "$PKG_DIR/lib/$arch/debug/libpiauto.so"
                echo "  ✓ lib/$arch/debug/libpiauto.so"
            fi
            [[ -f "$dbg" ]] && cp "$dbg" "$PKG_DIR/lib/$arch/libpiauto.so.dbg" && \
                echo "  ✓ lib/$arch/libpiauto.so.dbg"
        fi
    done
done

# ─────────────────────────────────────────────────────────────────────────────
# STEP 4: Copy PUBLIC headers only (NOT hal/, protocol/, jni/ internals)
# ─────────────────────────────────────────────────────────────────────────────
echo ""
echo "▶ Step 4/6: Copying public headers ..."

PUBLIC_HEADERS=(
    "core/include/piauto_sdk.h"
    "core/include/piauto_types.h"
    "core/include/piauto_callbacks.h"
    "core/include/piauto_log.h"
)

for hdr in "${PUBLIC_HEADERS[@]}"; do
    cp "$SDK_ROOT/$hdr" "$PKG_DIR/include/"
    echo "  ✓ include/$(basename "$hdr")"
done

# Stamp version into piauto_sdk.h comment block
sed -i "s/@VERSION@/$VERSION/g" "$PKG_DIR/include/piauto_sdk.h" 2>/dev/null || true

# ─────────────────────────────────────────────────────────────────────────────
# STEP 5: Configs + Docs + Licenses
# ─────────────────────────────────────────────────────────────────────────────
echo ""
echo "▶ Step 5/6: Copying configs, docs, licenses ..."

# Configs
cp "$SDK_ROOT/configs/audio_policy_configuration.xml" "$PKG_DIR/configs/"
cp "$SDK_ROOT/configs/car_audio_configuration.xml"    "$PKG_DIR/configs/"
cp "$SDK_ROOT/configs/device.mk.snippet"              "$PKG_DIR/configs/"
echo "  ✓ configs/ (3 files)"

# Docs
cp "$SDK_ROOT/docs/ARCHITECTURE.md" "$PKG_DIR/docs/"
echo "  ✓ docs/ARCHITECTURE.md"

# Generate INTEGRATION_GUIDE.md inline
cat > "$PKG_DIR/docs/INTEGRATION_GUIDE.md" << 'GUIDE_EOF'
# PiAutoSDK — OEM Integration Guide

## Quick Start (3 steps)

### Step 1: Add libpiauto.so to your Android.mk
```makefile
LOCAL_SHARED_LIBRARIES += libpiauto
LOCAL_C_INCLUDES       += $(LOCAL_PATH)/include/piauto
```

### Step 2: Copy configs to vendor partition
```makefile
PRODUCT_COPY_FILES += \
    vendor/piauto/configs/audio_policy_configuration.xml:$(TARGET_COPY_OUT_VENDOR)/etc/audio_policy_configuration.xml \
    vendor/piauto/configs/car_audio_configuration.xml:$(TARGET_COPY_OUT_VENDOR)/etc/car_audio_configuration.xml
```

### Step 3: Set required properties in device.mk
```makefile
PRODUCT_PROPERTY_OVERRIDES += \
    ro.android.car.audio.enableaudiopatch=true \
    ro.android.car.audio.configuration=/vendor/etc/car_audio_configuration.xml
```

### Step 4: Use the Java API
```java
PiAutoSDK sdk = new PiAutoSDK.Builder(this)
    .setCallback(this)
    .setScreenWidth(1920)
    .setScreenHeight(720)
    .build();
sdk.start();
```

## Support
Contact: sdk-support@piauto.dev
GUIDE_EOF
echo "  ✓ docs/INTEGRATION_GUIDE.md"

# Changelog
cat > "$PKG_DIR/docs/CHANGELOG.md" << CHANGELOG_EOF
# PiAutoSDK Changelog

## v${VERSION} (${DATE})
### Added
- Full Android Auto support (AOAP + TLS 1.2 over USB)
- Full CarPlay support (iAP2 + MFi auth RSA-2048)
- Lock-free SPSC ring buffer audio engine (SCHED_FIFO priority 90)
- 4-channel audio: Media, Navigation, Voice, Microphone
- USB hotplug detection via libusb-1.0
- JNI bridge with Java AudioTrack/AudioRecord integration
- CarAudioService bus configuration (AUDIO_DEVICE_OUT_BUS)

### Boards Tested
- Raspberry Pi 4 / Android 16
- NXP i.MX95 EVK / Android 15
CHANGELOG_EOF
echo "  ✓ docs/CHANGELOG.md"

# Licenses
cat > "$PKG_DIR/licenses/LICENSE.txt" << LICENSE_EOF
PiAutoSDK Commercial License

Copyright (C) $(date +%Y) PiAuto Inc. All rights reserved.

This software is proprietary and confidential.
Unauthorized copying, distribution, or modification is strictly prohibited.

Licensed to: ${OEM_NAME:-[OEM Customer Name]}
License type: Commercial OEM Integration License
Version: ${VERSION}
Issued: ${DATE}

For support: sdk-support@piauto.dev
LICENSE_EOF

cat > "$PKG_DIR/licenses/THIRD_PARTY_LICENSES.txt" << 'THIRD_EOF'
Third-Party Licenses included in libpiauto.so

1. libusb-1.0
   License: LGPL-2.1
   https://github.com/libusb/libusb

2. OpenSSL / BoringSSL
   License: Apache 2.0 (BoringSSL) / OpenSSL License
   https://boringssl.googlesource.com/boringssl/

3. tinyalsa
   License: BSD 3-Clause
   https://github.com/tinyalsa/tinyalsa

Full license texts available at their respective project URLs.
THIRD_EOF
echo "  ✓ licenses/ (2 files)"

# README
cat > "$PKG_DIR/README.md" << README_EOF
# PiAutoSDK v${VERSION}

OEM distribution package — Android Auto & CarPlay SDK for Android Automotive.

| Item | Value |
|------|-------|
| Version | ${VERSION} |
| Date | ${DATE} |
| Target ABI | ${TARGETS[*]} |
| Min Android API | 35 (Android 16) |
| License | Commercial OEM |

## Package Contents

\`\`\`
lib/            Pre-built shared library
include/        Public C headers (4 files)
java/           Java wrapper (AAR)
configs/        audio_policy + car_audio XML
docs/           Architecture, integration guide, changelog
licenses/       License files
\`\`\`

## Quick Start

See \`docs/INTEGRATION_GUIDE.md\`

## Support

sdk-support@piauto.dev
README_EOF
echo "  ✓ README.md"

# ─────────────────────────────────────────────────────────────────────────────
# STEP 6: Optional signing
# ─────────────────────────────────────────────────────────────────────────────
if [[ "$DO_SIGN" == true ]]; then
    echo ""
    echo "▶ Signing binaries ..."
    if [[ -z "${SIGN_KEY:-}" ]]; then
        echo "  [WARN] SIGN_KEY not set — skipping signing"
        echo "  To sign: export SIGN_KEY=/path/to/signing_key.pem"
    else
        for arch in "${TARGETS[@]}"; do
            so="$PKG_DIR/lib/$arch/libpiauto.so"
            if [[ -f "$so" ]]; then
                openssl dgst -sha256 -sign "$SIGN_KEY" -out "${so}.sig" "$so"
                echo "  ✓ Signed: lib/$arch/libpiauto.so → .sig"
            fi
        done
    fi
fi

# ─────────────────────────────────────────────────────────────────────────────
# STEP 7: Create archive
# ─────────────────────────────────────────────────────────────────────────────
echo ""
echo "▶ Step 6/6: Creating archive ..."

cd "$OUT_DIR"
ARCHIVE="${PKG_NAME}.tar.gz"
tar -czf "$ARCHIVE" "$PKG_NAME/"

# Compute SHA256 checksum
CHECKSUM=$(sha256sum "$ARCHIVE" | cut -d' ' -f1)
echo "$CHECKSUM  $ARCHIVE" > "${ARCHIVE}.sha256"

echo "  ✓ Archive   : $OUT_DIR/$ARCHIVE"
echo "  ✓ Checksum  : $CHECKSUM"
echo "  ✓ SHA256    : $OUT_DIR/${ARCHIVE}.sha256"

# ─────────────────────────────────────────────────────────────────────────────
# Summary
# ─────────────────────────────────────────────────────────────────────────────
echo ""
echo "╔══════════════════════════════════════════════════════╗"
echo "║                 Package Summary                       ║"
echo "╠══════════════════════════════════════════════════════╣"
echo "║  Archive : $ARCHIVE"
echo "║  Size    : $(du -sh "$OUT_DIR/$ARCHIVE" | cut -f1)"
echo "║  SHA256  : ${CHECKSUM:0:16}..."
echo "╠══════════════════════════════════════════════════════╣"
echo "║  Contents:"
find "$PKG_DIR" -type f | sort | while read -r f; do
    rel="${f#$PKG_DIR/}"
    echo "║    $rel"
done
echo "╚══════════════════════════════════════════════════════╝"
echo ""
echo "  ✅ Package ready: $OUT_DIR/$ARCHIVE"
echo "  📋 Deliver to OEM: send .tar.gz + .sha256 together"
echo ""
